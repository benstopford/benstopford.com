/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.evolution;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;
import com.devsim.code.Class;
import com.devsim.code.CodeBase;
import com.devsim.code.Event;
import com.devsim.code.Function;
import com.devsim.plugins.PolicyFactory;
import com.devsim.requirements.RequirementRepository;
import com.devsim.requirements.dataobjects.Extension;
import com.devsim.requirements.dataobjects.Requirement;
import com.devsim.requirements.dataobjects.Task;
import com.devsim.utils.RandomGen;

/**
 *
 * The agent facilitates the evolution performed by the Evolution Policy.
 * Primarily it determines the starting class and function from the Task
 * and mediated the appropriate executrions of the evolution policy.
 *
 * @author Benjamin Stopford
 *
 * TODO To change the template for this generated type comment go to
 *
 */
public class Agent extends AgentController {
	private Memory agentMemory = new Memory(this);
	private final IEvolutionPolicy policy = PolicyFactory.getEvolutionPolicy(agentMemory);
	private static int maxid;
	private int id;

	//The Agent can only be constucted at package level (i.e. by the factory)
	Agent (){
		maxid++;
		id = maxid;
	}

	public String toString(){
		return "Agent:"+id;
	}

	/* (non-Javadoc)
	 * @see com.devsim.evolution.EvolutionTemplate#design(com.devsim.requirements.dataobjects.Requirement)
	 */
	protected Cost design(Requirement r) {
		//opertunity to switch evolutoin policy based on code base
		return Cost.NO_COST;
	}

	/* (non-Javadoc)
	 * @see com.devsim.evolution.EvolutionTemplate#implement(com.devsim.requirements.dataobjects.Requirement)
	 */
	protected Cost implement(Requirement newReq) {

		getApi().startCosting(this);
		Cost totalCost = new Cost();

		List taskList = newReq.getTasks();
		Extension unitToExtend = newReq.getOperatesOn();
		RequirementRepository reqRepo = RequirementRepository.getInstance();
		Function startingFunction=null;

		//if it is a new event then add it in a new class with a new function
		if(unitToExtend.getRequirementType().isSystemEvent()){
			//startingClass = ;
			Event ev = getApi().createEvent(unitToExtend.getTask());
			startingFunction = ev;

		}else{
			//operating on an exisiting task so check it exists
			if(!reqRepo.exists(unitToExtend.getParent())){
				throw new RuntimeException("The task that is being changed has not been coded yet. Extendion:"+unitToExtend.toString());
			}
		}
		if(newReq.getChangeType().isNew()){
			implementNew(totalCost, taskList, unitToExtend, startingFunction);
		}
		else if(newReq.getChangeType().isAugment()){
			implementAugment(newReq, totalCost, unitToExtend);
		}
		else if(newReq.getChangeType().isChange()){
			implementChange(newReq, totalCost, unitToExtend);
		}
		totalCost.add(getApi().getCost());
		return totalCost;
	}

	/**
	 * Make changes for a New requirement
	 * @param newReq
	 * @param totalCost
	 * @param unitToExtend
	 */
	private void implementChange(Requirement newReq, Cost totalCost, Extension unitToExtend) {
		Iterator tasks = newReq.getTasks().iterator();

		while(tasks.hasNext()){
			Task newTask = (Task)tasks.next();
			//this will only be a change to a task
			Task taskToExtend = unitToExtend.getTask();

			Iterator functions = CodeBase.getAPI().getFunctionsForTask(taskToExtend).iterator();
			Function f=null;
			while(functions.hasNext()){
				f = (Function)functions.next();
				totalCost.add(policy.processChange(f, newTask));
			}
		}
	}

	/**
	 *  Make changes for an Augmented requirement
	 * @param newReq
	 * @param totalCost
	 * @param unitToExtend
	 */
	private void implementAugment(Requirement newReq, Cost totalCost, Extension unitToExtend) {
		Iterator tasksToAugment;
		Iterator tasksToImplement;

		// AUGMENT functionality will always be changing a Requirement.
		if(unitToExtend.isRequirement()){
			Requirement reqToAugment = unitToExtend.getRequirement();
			if (reqToAugment==null){
				throw new RuntimeException("Requirement is null but needs to be supplied for an augmentation.");
			}

			//Augmentation operates on all the requirements
			tasksToAugment = reqToAugment.getTasks().iterator();
		}
		else{
			Task task = unitToExtend.getTask();
			if (task==null){
				throw new RuntimeException("Task is null but needs to be supplied for an augmentation.");
			}

			//Augmentation operates on all the requirements
			List tasksToAugmentList = new ArrayList();
			tasksToAugmentList.add(task);
			tasksToAugment = tasksToAugmentList.iterator();
		}
		tasksToImplement = newReq.getTasks().iterator();

		//loop through each existing task that must be augmented
		while (tasksToAugment.hasNext()){
			Task taskToAugment = (Task)tasksToAugment.next();
			Iterator functionsToAugment = getApi().getFunctionsForTask(taskToAugment).iterator();

			//loop through each task that must be implemented as new functionality
			while (tasksToImplement.hasNext()){
				Task taskToImplement = (Task)tasksToImplement.next();
				if(RandomGen.getPercentage() < newReq.getAugmentationPercentage()){

					//loop through each of the functions for the top level task that is being augmented
					while(functionsToAugment.hasNext()){
						Function f = (Function)functionsToAugment.next();
						//proceed with augmenting the class
						totalCost.add(policy.processAugmentation(f,taskToImplement));
					}
				}
			}
		}
	}

	/**
	 *  Make changes for Changed requirement
	 * @param totalCost
	 * @param taskList
	 * @param unitToExtend
	 * @param startingFunction
	 */
	private void implementNew(Cost totalCost, List taskList, Extension unitToExtend, Function startingFunction) {
		// New functionality may have a specified starting Task or Requirement.
		// New functionality however is only only ever started from one class
		// chosen at random if the task or requirement that is being extended
		// has several to choose from.
		if(unitToExtend.isRequirement()&&startingFunction==null){
			Requirement r = unitToExtend.getRequirement();
			Task firstTask = (Task)r.getTasks().iterator().next();
			//startingClass = getApi().getFirstClassForTask(firstTask);
			startingFunction = (Function)RandomGen.getRandom(getApi().getFunctionsForTask(firstTask));
		}
		else if(unitToExtend.isTask()&& startingFunction==null){
			Task t =unitToExtend.getTask();
			Class startingClass = getApi().getFirstClassForTask(t);
			startingFunction = getApi().getFirstFunctionForClass(startingClass);
		}
		if (startingFunction==null){
			throw new RuntimeException("The starting function needs to have been found by this point.");
		}
		Iterator tasks = taskList.iterator();
		while(tasks.hasNext()){
			Task task = (Task)tasks.next();
			totalCost.add(policy.processNewTask(startingFunction, task));
		}
	}

	/* (non-Javadoc)
	 * @see com.devsim.evolution.EvolutionTemplate#test(com.devsim.requirements.dataobjects.Requirement)
	 */
	protected Cost test(Requirement r) {
		//assume testing is proportional to the number of functions that were changed
		return Cost.NO_COST;
	}

	/* (non-Javadoc)
	 * @see com.devsim.evolution.EvolutionTemplate#complete()
	 */
	protected void complete(Requirement r) {

		//all the functions created as part of the
		//tasks implemented by this agent in this epoch
		//are added to the agents memory

		Iterator tasks = r.getTasks().iterator();
		while (tasks.hasNext()){
			Task t = (Task)tasks.next();
			Iterator functions = getApi().getFunctionsForTask(t).iterator();
			while (functions.hasNext()){
				Function f = (Function)functions.next();
				agentMemory.add(f);

			}
		}
	}

	public Memory getMemory() {
		return agentMemory;
	}
}
