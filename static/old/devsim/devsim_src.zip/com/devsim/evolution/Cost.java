package com.devsim.evolution;

/**
 * @author Benjamin Stopford
 *
 * Cost is the basic measure of the simulation.
 */
public class Cost {
	public static final Cost NO_COST = new Cost(){
		public int getTotalCost(){
			return 0;
		}
	};
	
	private int _costImplementation;
	private int _costComplexity;
	private int _numberOfRememberedFunctions;
	
	public Cost() {}

	public Cost(int implementationCost) {
		_costImplementation = implementationCost;
		}
	public void addImplementaton(int cost){
		_costImplementation+=cost;
	}
	public void addComplexity(int cost){
		_costComplexity+=cost;
	}
	public void addRemembered(){
		_numberOfRememberedFunctions++;
	}
	public void add(Cost cost){
		_costImplementation+=cost.getImplementationCost();
		_costComplexity+=cost.getComplexityCost();	
		_numberOfRememberedFunctions+=cost.getNumberOfRecals();
	}	
	public int getNumberOfRecals(){
		return _numberOfRememberedFunctions;
	}
	public int getTotalCost(){
		return _costImplementation+_costComplexity;
	}
	public int getImplementationCost(){
		return _costImplementation;
	}
	public int getComplexityCost(){
		return _costComplexity;
	}
}
