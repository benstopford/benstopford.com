/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.evolution;

import com.devsim.code.CodeBase;
import com.devsim.code.CodeBaseAPI;
import com.devsim.requirements.dataobjects.Requirement;

/**
 * @author Benjamin Stopford
 *Super class to the agent the agent controller represents the template for
 *the agents actions. This class represents a Template pattern that defines 
 *the template for the implementation of a requirement by the agent.
 */
public abstract class AgentController {

	public static Cost TOTAL_COST = new Cost();
	public static int AV_IMPLEMENTATION_COST = 0;
	public AgentController(){
	}

	public final Cost implementRequirement(Requirement r){
		Cost total = new Cost();
		total.add(design(r));
		total.add(implement(r));
		total.add(test(r));
		complete(r);
		r.implemented = true;
		TOTAL_COST.add(total);
		if(AV_IMPLEMENTATION_COST>0)
			AV_IMPLEMENTATION_COST = (AV_IMPLEMENTATION_COST+total.getTotalCost())/2;
		else
			AV_IMPLEMENTATION_COST = total.getTotalCost();
		return total;
	}


	/**
	 * Following methods are here for extension only. Implement
	 * is the only one that is currently used
	 */
	protected abstract Cost design(Requirement r);
	protected abstract Cost implement(Requirement r);
	protected abstract Cost test(Requirement r);
	protected abstract void complete(Requirement r);

	/**
	 * @return Returns the _api.
	 */
	protected CodeBaseAPI getApi() {
		return CodeBase.getAPI();
	}

}
