/*
 * Created on 26-Aug-2005
 *
 *
 *
 */
package com.devsim.evolution;

import java.util.HashMap;
import java.util.Map;


import com.devsim.code.CodeConstruct;
import com.devsim.plugins.EnvironmentVariable;

/**
 * @author Ben
 *
 * The Memory class holds the agents memory. In
 * particular it allows the calculation of a
 * discount factor which simulates the loss
 * of memory over time.
 *
 * Time is established from the average effort
 * taken to implement a requirement.  Memory is
 * currently set up to be eternal in in the
 * simulation but this can easily be changed
 * to leak by altering CodeMetrics class to
 * use the Memory. remembersPortion method.
 */

public class Memory {

	private Map memories = new HashMap();

	public Memory(Agent agent){
	}

	public void add(CodeConstruct cc){
		//map constuct to time
		memories.put(cc,new Integer(getTime()));
	}

	private int getTime(){
		return AgentController.TOTAL_COST.getTotalCost();
	}
	/**
	 * Does the agent remember this code construct??
	 * @param cc
	 * @return
	 */
	public boolean remembers(CodeConstruct cc){
		return memories.containsKey(cc);
	}

	/**
	 * Does the agent remember this code construct??
	 * Returns a number between 0 and 1. 1 is full memeory
	 * and 0 is no memory.
	 * @param cc
	 * @return
	 */
	public double remembersPortion(CodeConstruct cc){
		if (memories.containsKey(cc)){
			Integer startTime = (Integer)memories.get(cc);
			double timePassed = getTime()-startTime.intValue();
			//memory lasts for 100 epochs in total
			double max = AgentController.AV_IMPLEMENTATION_COST * EnvironmentVariable.MAX_EPOCHS_BEFORE_MEMORY_LOSS;

			if(timePassed>max)return 0;
			else
			{
				return 1-timePassed/max;
			}
		}
		return 0;
	}

}

