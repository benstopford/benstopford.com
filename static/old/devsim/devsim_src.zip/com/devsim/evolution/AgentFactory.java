/*
 * Created on 29-Aug-2005
 *
 *
 *
 */
package com.devsim.evolution;

import java.util.HashSet;
import java.util.Set;

import com.devsim.plugins.EnvironmentVariable;
import com.devsim.utils.RandomGen;


/**
 * The Agent Factory is responsible for creating and supplying
 * the multiple agents that may exist in the system. The number
 * of agents in the simulation is controlled by a setting in
 * the file Settings.java in the plug-ins package. When multiple
 * agents are specified a different agent will be selected from
 * the pool for each new requirement that is implemented.
 *
 * @author Ben
 *
 */
public class AgentFactory {
	private static AgentFactory factory = new AgentFactory();
	private Set agents = new HashSet();

	public static final AgentFactory getInstance(){
		return factory;
	}
	private AgentFactory(){
		createAgents();
	}
	public static void reset(){
		factory = new AgentFactory();
	}

	private void createAgents() {
		//create the defined number of agents
		agents.clear();
		int agentCount = EnvironmentVariable.NUMBER_OF_AGENTS;
		while(agentCount>0){
			agents.add(new Agent());
			agentCount--;
		}
	}
	public Agent getRandomAgent(){
		return (Agent)RandomGen.getRandom(agents);
	}

}
