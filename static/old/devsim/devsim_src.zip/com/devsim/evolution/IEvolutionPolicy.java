/*
 * Created on 27-Aug-2005
 */
package com.devsim.evolution;

import com.devsim.code.CodeConstruct;
import com.devsim.code.CouplingType;
import com.devsim.code.Function;
import com.devsim.requirements.dataobjects.Task;

/**
 * The Evolution Policy is the plug-in that determines
 * how the code base evolves (along with the Complexity Injector).
 * This is the fundamental place where experiments are configured.
 * The evolution policy has access to a variety of attributes of
 * the simulation that can be used to alter the way that the
 * simulation evolves.
 * 
 * In each case the evolution policy implementation must be responsible
 * for the turning of 
 *
 * @author Ben
 *
 */
public interface IEvolutionPolicy {
	/**
	 * Create the code associated with the new task passed which is of 
	 * requirement type NEW
	 * 
	 * @param startingFunction - the function to start processing from
	 * @param task - the task to process
	 */
	public Cost processNewTask(Function startingFunction, Task task);

	/**
	 * Augment the base function with the new task of requrement type 
	 * AUGMENT
	 * 
	 * @param startingFunction  - the function to start processing from
	 * @param task - the task to process
	 */
	public Cost processAugmentation(Function startingFunction, Task task);

	/**
	 * Change code from an exising Task as specified in the new Task
	 * that is of requirement type CHANGE
	 * 
	 * @param startingFunction - the function to start processing from
	 * @param newTask - the task to process
	 */
	public Cost processChange(Function startingFunction, Task newTask);

	/**
	 * Determine the coupling type that should be used for this caller and provider
	 * @param caller
	 * @param provider
	 * @return
	 */
	public CouplingType getCouplingType(CodeConstruct caller, CodeConstruct provider);
		
}