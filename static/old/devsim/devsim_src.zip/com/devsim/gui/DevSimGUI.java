/*
 * Created on Aug 13, 2005
 *
 *
 *
 */
package com.devsim.gui;

import java.awt.BorderLayout;
import java.awt.Component;
import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.Enumeration;
import java.util.Iterator;

import javax.swing.AbstractAction;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTabbedPane;
import javax.swing.JTextArea;
import javax.swing.JTextField;
import javax.swing.JTree;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.TreeNode;
import javax.swing.tree.TreePath;


import com.devsim.code.CodeBase;
import com.devsim.code.CodeBaseAnalyser;
import com.devsim.evolution.AgentFactory;
import com.devsim.evolution.Cost;
import com.devsim.plugins.EnvironmentVariable;
import com.devsim.plugins.PolicyFactory;
import com.devsim.requirements.RequirementRepository;
import com.devsim.requirements.RequirementsFactory;
import com.devsim.requirements.dataobjects.Requirement;
import com.devsim.utils.FileLog;


/**
 * @author Benjamin Stopford
 *
 *Main class for teh DevSim GUI application
 */
public class DevSimGUI {
	 private JTextField implementationCostTxt = new JTextField();
	 private JTextField complexityCostTxt = new JTextField();
	 private JTextField epochsTxt = new JTextField();
	 private JTextField tasksTxt = new JTextField();
	 private JTextField classTxt = new JTextField();
	 private JTextField fnTxt = new JTextField();
	 private JTextField avFnPerClTxt = new JTextField();
	 private JTextField avTskPrFnTxt = new JTextField();
	 private JTextArea log = new JTextArea();
	 private JButton _btnProcessRequirement;
	 private JButton _btnGenerateReq;
	 private CodeBaseTree codeTreePaneEvent;
	 private CodeBaseTree codeTreePaneClass;
	 private JFrame frame;
	 private JButton processRequirementBtn;
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private void createAndShowGUI() {

        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        frame = new JFrame("Development Simulator");
		frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        JPanel mainPanel = new JPanel(new BorderLayout());

        final JTabbedPane tabs = new JTabbedPane();

        //create requirments tree tab
        final RequirementsTree reqTreePane = new RequirementsTree(RequirementsFactory.getGenerator().generateRequirements(10));
        reqTreePane.setOpaque(true); //content panes must be opaque
        tabs.addTab("Requirements",reqTreePane);

        codeTreePaneClass = new CodeBaseTree(false);
		codeTreePaneClass.setOpaque(true); //content panes must be opaque
        tabs.addTab("CodeBase (Class Drill View)",codeTreePaneClass);

        codeTreePaneEvent = new CodeBaseTree(true);
		codeTreePaneEvent.setOpaque(true); //content panes must be opaque
        tabs.addTab("CodeBase (Event View)",codeTreePaneEvent);

        //create controls panel
        JPanel controlsPanel = new JPanel(new GridLayout(8,1));

        _btnGenerateReq = new JButton(reqTreePane.getAddReqAction());
		final JButton clearReqs = new JButton(reqTreePane.getClearAction());
		final JButton clearCode = new JButton(getClearCodeBaseAction());
		JButton clearAll = new JButton(new AbstractAction("Clear All"){
			public void actionPerformed(ActionEvent e) {
				clearCode.doClick();
				clearReqs.doClick();
			}
		});
        _btnProcessRequirement = getProcessReqButton(reqTreePane, codeTreePaneClass,codeTreePaneEvent);
		JButton expand = getExpandAllButton(tabs);
        JButton collapse = getCollapseAllButton(tabs);

        controlsPanel.add(_btnGenerateReq);
        controlsPanel.add(_btnProcessRequirement);
        controlsPanel.add(expand);
        controlsPanel.add(collapse);
        controlsPanel.add(clearReqs);
        controlsPanel.add(clearCode);
        controlsPanel.add(clearAll);
        controlsPanel.add(getRefreshCode());
        JPanel outerPanel = new JPanel(new GridLayout(2,1));
        outerPanel.add(getResultsComponent());
        outerPanel.add(controlsPanel);

        JPanel logPanel = new JPanel(new BorderLayout());
        JScrollPane scroll = new JScrollPane(log);

        logPanel.add(scroll,BorderLayout.CENTER);

        tabs.addTab("Log Readout",logPanel);

		mainPanel.add(tabs,BorderLayout.CENTER);
        mainPanel.add(outerPanel,BorderLayout.EAST);
        mainPanel.setPreferredSize(new Dimension(1000,650));

        frame.setContentPane(mainPanel);

        //Display the window.
        frame.pack();

        frame.setVisible(true);
    }

    private JPanel getResultsComponent(){
    	JPanel main = new JPanel(new GridLayout(12,2));
    	main.add(new JLabel("Epochs Completed:"));
    	main.add(epochsTxt);
    	main.add(new JLabel("Tasks Completed:"));
    	main.add(tasksTxt);
    	main.add(new JLabel("Total Classes:"));
    	main.add(classTxt);
    	main.add(new JLabel("Total Functions:"));
    	main.add(fnTxt);
    	main.add(new JLabel("Av Functions Per Class:"));
    	main.add(avFnPerClTxt);
    	main.add(new JLabel("Av Tasks Per Function:"));
    	main.add(avTskPrFnTxt);
    	main.add(new JLabel("Implementation Cost"));
    	main.add(implementationCostTxt);
    	main.add(new JLabel("Metric Cost"));
    	main.add(complexityCostTxt);

    	final JTextField numberToImplement = new JTextField();
    	JButton bBulk = new JButton (new AbstractAction("Implement Multiple"){
			public void actionPerformed(ActionEvent e) {
				Integer num = null;
				try {
					num = new Integer(numberToImplement.getText());
				} catch (NumberFormatException e1) {
					numberToImplement.setText("This must be a number");
					return;
				}
				int i = num.intValue();
				while (i>0){
					i--;
					_btnGenerateReq.doClick();
					_btnProcessRequirement.doClick();
				}
			}
    	});

    	main.add(numberToImplement);
    	main.add(bBulk);

    	final JTextField fileName = new JTextField();
    	JButton save = new JButton(new AbstractAction("Save To Log"){
			public void actionPerformed(ActionEvent e) {
				if(fileName.getText()!=""){
					EnvironmentVariable.PATH_TO_LOG = "C:\\"+fileName.getText()+".txt";
				}
				FileLog.save();
			}
        });
    	main.add(fileName);
    	main.add(save);


    	final JTextField numDeveopers = new JTextField(EnvironmentVariable.NUMBER_OF_AGENTS+"");

    	JButton saveDevs = new JButton(new AbstractAction("Save Number of Developers."){
			public void actionPerformed(ActionEvent e) {
				int newNum = 0;
				try {
					 newNum= (new Integer(numDeveopers.getText())).intValue();
				} catch (NumberFormatException e1) {
					e1.printStackTrace();
					return;
				}
				if(newNum>0)
					EnvironmentVariable.NUMBER_OF_AGENTS = newNum;
			}
        });
    	main.add(numDeveopers);
    	main.add(saveDevs);
    	return main;
    }

    private void requirementComplete(Cost newCost,Requirement r){
    	getCurrentCost().add(newCost);
    	implementationCostTxt.setText(getCurrentCost().getImplementationCost()+"");
    	complexityCostTxt.setText(getCurrentCost().getComplexityCost()+"");
    	epochsTxt.setText(RequirementRepository.getInstance().getImplementedRequriementCount()+"");
    	tasksTxt.setText(RequirementRepository.getInstance().getImplementedTaskCount()+"");
    	classTxt.setText(CodeBase.getAPI().getClasses().size()+"");
    	fnTxt.setText(CodeBaseAnalyser.getNumberFunctions()+"");
    	avFnPerClTxt.setText(CodeBaseAnalyser.getAvFunctionsPerClass()+"");
    	avTskPrFnTxt.setText(CodeBaseAnalyser.getAvNumberOfTasksPerFunction()+"");
    	FileLog.logRequirementCost(getCurrentCost(),r);
    	log.setText(FileLog.getLog());
    }


    private JButton getCollapseAllButton(final JTabbedPane tabs) {
		JButton collapse = new JButton(
        		new AbstractAction("Collapse All"){
					public void actionPerformed(ActionEvent e) {
						 Component c = tabs.getSelectedComponent();
						 if(c instanceof RequirementsTree){
						 	RequirementsTree tree = (RequirementsTree)c;
						 	expandAll(tree.tree,false);
						 }
						 else if(c instanceof CodeBaseTree){
						 	CodeBaseTree tree = (CodeBaseTree)c;
						 	expandAll(tree.tree,false);
						 }
						 else{
						 	System.err.println("wrong type??");
						 }

					}
        		}
        );
		return collapse;
	}

	private JButton getExpandAllButton(final JTabbedPane tabs) {
		JButton expand = new JButton(
        		new AbstractAction("Expand All"){
					public void actionPerformed(ActionEvent e) {
						 Component c = tabs.getSelectedComponent();
						 if(c instanceof RequirementsTree){
						 	RequirementsTree tree = (RequirementsTree)c;
						 	expandAll(tree.tree,true);
						 }
						 else if(c instanceof CodeBaseTree){
						 	CodeBaseTree tree = (CodeBaseTree)c;
						 	expandAll(tree.tree,true);
						 }
						 else{
						 	System.err.println("wrong type??");
						 }

					}
        		}
        );
		return expand;
	}

	private JButton getProcessReqButton(final RequirementsTree reqTreePane, final CodeBaseTree codeTreePane1, final CodeBaseTree codeTreePane2) {
		JButton processRequirement = new JButton(
        		new AbstractAction("Add Requirments To Code Base"){
					public void actionPerformed(ActionEvent e) {
//						System.out.println("Called: Add Requirments To Code Base");
						Iterator requirements =
							 RequirementRepository.getInstance().getRequirements().iterator();

//						System.out.println("START IMPLEMENTING REQUIREMENTS IN CODE BASE");
						while(requirements.hasNext()){
							Requirement r = (Requirement)requirements.next();
							if(r.implemented==false){
//								System.out.println("Implementing Requirmeent:"+r.toString());
								Cost cost = AgentFactory.getInstance().getRandomAgent().implementRequirement(r);
								requirementComplete(cost,r);
							}
							else{
								//System.err.println("Requirement has already been implemented!! - "+r.toString());
							}
						}

						codeTreePane1.refresh();
						codeTreePane2.refresh();


					}
        		}
        );
		return processRequirement;
	}

	private JButton getRefreshCode() {
		processRequirementBtn = new JButton(
		        		new AbstractAction("Press to Check Version"){
							public void actionPerformed(ActionEvent e) {
								processRequirementBtn.setText( "Version is "+PolicyFactory.getRequirementsPolicy().getVersion());
							}
		        		}
		        );
		return processRequirementBtn;
	}
	// If expand is true, expands all nodes in the tree.
    // Otherwise, collapses all nodes in the tree.
    public static void expandAll(JTree tree, boolean expand) {
    	DefaultMutableTreeNode root = (DefaultMutableTreeNode)tree.getModel().getRoot();
        // Traverse tree from root
        expandAll(tree, new TreePath(root), expand);
    }
    private static void expandAll(JTree tree, TreePath parent, boolean expand) {
        // Traverse children
        TreeNode node = (TreeNode)parent.getLastPathComponent();
        if (node.getChildCount() >= 0) {
            for (Enumeration e=node.children(); e.hasMoreElements(); ) {
                TreeNode n = (TreeNode)e.nextElement();
                TreePath path = parent.pathByAddingChild(n);
                expandAll(tree, path, expand);
            }
        }

        // Expansion or collapse must be done bottom-up
        if (expand) {
            tree.expandPath(parent);
        } else {
            tree.collapsePath(parent);
        }
    }

    public AbstractAction getClearCodeBaseAction(){
    	return new AbstractAction("Clear CodeBase"){
			public void actionPerformed(ActionEvent e) {

				//flag all requriements as unimplemented
				RequirementRepository.getInstance().markAllUnimplemented();
				//reset the code base
				CodeBase.resetCodeBase();

				//update the GUI and log
				codeTreePaneClass.clearTree();
				codeTreePaneEvent.clearTree();
				FileLog.clear();
				requirementComplete(new Cost(),Requirement.NULL);
			}
    	};
    }

    public static void main(String[] args) {
        //Schedule a job for the event-dispatching thread:
        //creating and showing this application's GUI.
        javax.swing.SwingUtilities.invokeLater(new Runnable() {
            public void run() {
                (new DevSimGUI()).createAndShowGUI();
            }
        });
    }

	/**
	 * @return Returns the currentCost.
	 */
	public Cost getCurrentCost() {
		return CodeBase.getTotalCost();
	}
}
