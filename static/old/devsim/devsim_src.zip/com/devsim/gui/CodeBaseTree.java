/*
 * Created on Aug 10, 2005
 * A tree view that deals represents 
 * the code base.
 */
package com.devsim.gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.util.Iterator;
import java.util.Set;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;

import com.devsim.code.Class;
import com.devsim.code.CodeBase;
import com.devsim.code.CodeConstruct;
import com.devsim.code.Event;
import com.devsim.code.Function;
import com.devsim.code.Property;
import com.devsim.code.Reference;
import com.devsim.requirements.dataobjects.Task;

public class CodeBaseTree extends JPanel
                      implements TreeSelectionListener {
    private JEditorPane htmlPane;
    JTree tree;
    private static boolean playWithLineStyle = false;
    private static String lineStyle = "Horizontal";
    
    //Optionally set the look and feel.
    private static boolean useSystemLookAndFeel = false;
    boolean eventView;
    DefaultMutableTreeNode top;
    public CodeBaseTree(boolean eventView) {
        super(new GridLayout(1,0));
        
        this.eventView = eventView;
        //Create the nodes.

         top = createFreshRoot();
        
        //Create a tree that allows one selection at a time.
        tree = new JTree(top);
        tree.getSelectionModel().setSelectionMode
                (TreeSelectionModel.SINGLE_TREE_SELECTION);
        
        //Listen for when the selection changes.
        tree.addTreeSelectionListener(this);

        if (playWithLineStyle) {
            tree.putClientProperty("JTree.lineStyle", lineStyle);
        }

        //Create the scroll pane and add the tree to it. 
        JScrollPane treeView = new JScrollPane(tree);

        //Create the HTML viewing pane.
        htmlPane = new JEditorPane();
        htmlPane.setEditable(false);

        JScrollPane htmlView = new JScrollPane(htmlPane);

        //Add the scroll panes to a split pane.
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setTopComponent(treeView);
        //splitPane.setBottomComponent(htmlView);

        Dimension minimumSize = new Dimension(100, 50);
        htmlView.setMinimumSize(minimumSize);
        treeView.setMinimumSize(minimumSize);
        splitPane.setDividerLocation(200); //XXX: ignored in some releases
                                           //of Swing. bug 4101306
        splitPane.setPreferredSize(new Dimension(500, 300));

        //Add the split pane to this panel.
        add(splitPane);
    }

    /** Required by TreeSelectionListener interface. */
    public void valueChanged(TreeSelectionEvent e) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)
                           tree.getLastSelectedPathComponent();
    		displayTest("");
   
    		if (node == null) return;

        checkFunctionNode(node); 
    }

    /**
     * Adds to the leaves to the function node
	 * @param node
	 * @param addedsomething
	 */
	private void checkFunctionNode(DefaultMutableTreeNode node) {
		Object nodeInfo = node.getUserObject();
        if (node.isLeaf()) {
        	if(nodeInfo instanceof Function){
        		Function f = (Function)nodeInfo;

        		Iterator tasks = f.getTasks().iterator();
        		while(tasks.hasNext()){
        			Task t = (Task)tasks.next();
        			DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(t);
        			node.add(newNode);
    	        }

        	}
        	if(nodeInfo instanceof Function){
            	CodeConstruct cc = (CodeConstruct)nodeInfo;
        		Set refs = CodeBase.getAPI().getReferencesProvidersForCaller(cc);
        		DefaultMutableTreeNode outNode = new DefaultMutableTreeNode("Outward Refs");
            	node.add(outNode);
            	
        		if(refs!=null){
	        		Iterator outwardRefs = refs.iterator();
	        		while(outwardRefs.hasNext()){
	        			Reference r = (Reference)outwardRefs.next();
	        			
	        			DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(r);
	        			outNode.add(newNode);
	        			
	        			DefaultMutableTreeNode newFnNode = new DefaultMutableTreeNode(r.getProvider());
	        			newNode.add(newFnNode);
	        			
			        }
        		}
        	}
        	if(nodeInfo instanceof Property){
            	CodeConstruct cc = (CodeConstruct)nodeInfo;
            	DefaultMutableTreeNode outNode = new DefaultMutableTreeNode("Type");
            	DefaultMutableTreeNode inNode = new DefaultMutableTreeNode("Inward Refs");
            	node.add(outNode);
            	node.add(inNode);
    			            	
        		Set refs = CodeBase.getAPI().getReferencesProvidersForCaller(cc);
        		if(refs!=null){
	        		Iterator outwardRefs = refs.iterator();
	        		while(outwardRefs.hasNext()){
	        			Reference r = (Reference)outwardRefs.next();
	        			
	        			DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(r);
	        			outNode.add(newNode);
	        			
	        			DefaultMutableTreeNode newFnNode = new DefaultMutableTreeNode(r.getProvider());
	        			newNode.add(newFnNode);
	        		}
        		}
        		
        		refs = CodeBase.getAPI().getReferencesCallersForProvider(cc);
        		if(refs!=null){
	        		Iterator outwardRefs = refs.iterator();
	        		while(outwardRefs.hasNext()){
	        			Reference r = (Reference)outwardRefs.next();
	        			
	        			DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(r);
	        			inNode.add(newNode);
	        			
	        			DefaultMutableTreeNode newFnNode = new DefaultMutableTreeNode(r.getProvider());
	        			newNode.add(newFnNode);
	        		}
        		}
        	}
        }
	}

	private void displayTest(String text) {
		if(htmlPane!=null)
        	htmlPane.setText(text);
    }
    
    /**
     * There are two ways of creating nodes in the code base view.
     * - create a class diagram. This is simply a list of classes with the methods
     * that they contain. When you click on a function node it drills all references to that
     * that function.
     * 

     */    
    private void createNodesClassList(DefaultMutableTreeNode top) {
        
    	//add all the global properties to the root
    	Iterator globals = CodeBase.getAPI().getPropertiesGlobal().iterator();
    	DefaultMutableTreeNode globOuterNode = new DefaultMutableTreeNode("Global Variables");
		top.add(globOuterNode);
    	while(globals.hasNext()){
			Property p = (Property)globals.next();
			DefaultMutableTreeNode globNode = new DefaultMutableTreeNode(p);
			globOuterNode.add(globNode);    		
		}
    	
    	Iterator classes = CodeBase.getAPI().getClasses().iterator();
		while(classes.hasNext()){
    		Class c = (Class)classes.next();
    		addClassToTree(top, c);
		}
    }

	private void addClassToTree(DefaultMutableTreeNode top, Class c) {
		DefaultMutableTreeNode classNode = new DefaultMutableTreeNode(c);
		top.add(classNode);
		
		//add all the class level properties to this class node
		Iterator props = c.getProperties().iterator();
		DefaultMutableTreeNode propsNode = new DefaultMutableTreeNode("Properties");
		classNode.add(propsNode);
		while(props.hasNext()){
			Property p = (Property)props.next();
			DefaultMutableTreeNode propNode = new DefaultMutableTreeNode(p);        		
			propsNode.add(propNode);
		}
		
		//add all the functions to this class node
		Iterator functions = c.getFunctions().iterator();
		while(functions.hasNext()){
			Function f = (Function)functions.next();
			addFunctionToTree(classNode, f);
		}
	}
    
	private void addFunctionToTree(DefaultMutableTreeNode classNode, Function f) {
		DefaultMutableTreeNode funcNode = new DefaultMutableTreeNode(f);        		
		classNode.add(funcNode);
		checkFunctionNode(funcNode);
	}

	/*
    * - the second is the event diagram view. In this view the root nodes enumerate
    * all the system events classes. nodes are then connect via outward references
    * to other classes. Thus the tree branches into the possible runs of the system
    */
    private void createNodesEventList(DefaultMutableTreeNode top) {
        
    	//add all the global properties to the root
    	Iterator events = CodeBase.getAPI().getSystemEvents().iterator();
		while(events.hasNext()){
			Event e = (Event)events.next();
			DefaultMutableTreeNode node = new DefaultMutableTreeNode(e);
    		top.add(node);   
    		
    		//add tasks to event
    		Iterator tasks = e.getTasks().iterator();
    		while(tasks.hasNext()){
    			Task t = (Task)tasks.next();
    			DefaultMutableTreeNode newNode = new DefaultMutableTreeNode(t);
    			node.add(newNode);
	        }

    		addFunctionToTree(node, e);    		
		}
    }
    
    private DefaultMutableTreeNode createFreshRoot(){
        DefaultMutableTreeNode top =
            new DefaultMutableTreeNode("Code Base");
        if(eventView){
        	 createNodesEventList(top);
        }else{
        	createNodesClassList(top);
        }
        return top;
    }
    
    public void refresh(){
    	tree.setModel(new DefaultTreeModel(createFreshRoot()));
    }
    
    
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        if (useSystemLookAndFeel) {
            try {
                UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                System.err.println("Couldn't use system look and feel.");
            }
        }

        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create and set up the window.
        JFrame frame = new JFrame("Requirements Viewer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
        
        //Create and set up the content pane.
        CodeBaseTree newContentPane = new CodeBaseTree(true);
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

    public void clearTree(){

		tree.setModel(new DefaultTreeModel(top = createFreshRoot()));
    }
    
}
