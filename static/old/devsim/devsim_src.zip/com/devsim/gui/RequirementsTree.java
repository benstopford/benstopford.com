/*
 * Created on Aug 10, 2005
 *
 *Represents a tree view of the requirements in the simulation
 */
package com.devsim.gui;

import java.awt.Dimension;
import java.awt.GridLayout;
import java.awt.event.ActionEvent;
import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import javax.swing.AbstractAction;
import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JSplitPane;
import javax.swing.JTree;
import javax.swing.UIManager;
import javax.swing.event.TreeSelectionEvent;
import javax.swing.event.TreeSelectionListener;
import javax.swing.tree.DefaultMutableTreeNode;
import javax.swing.tree.DefaultTreeModel;
import javax.swing.tree.TreeSelectionModel;

import com.devsim.requirements.RequirementRepository;
import com.devsim.requirements.RequirementsFactory;
import com.devsim.requirements.dataobjects.Extension;
import com.devsim.requirements.dataobjects.Requirement;

public class RequirementsTree extends JPanel
                      implements TreeSelectionListener {
    private JEditorPane htmlPane;
    JTree tree;

    //Optionally play with line styles.  Possible values are
    private static boolean playWithLineStyle = false;
    private static String lineStyle = "Horizontal";
    DefaultMutableTreeNode root = null;
    
    //Optionally set the look and feel.
    private static boolean useSystemLookAndFeel = false;

    public RequirementsTree(List reqs) {
        super(new GridLayout(1,0));

        root = getNewRoot();
        addRequirementToNode(root,reqs);

        //Create a tree that allows one selection at a time.
        tree = new JTree(root);
        tree.getSelectionModel().setSelectionMode
                (TreeSelectionModel.SINGLE_TREE_SELECTION);

        //Listen for when the selection changes.
        tree.addTreeSelectionListener(this);

        if (playWithLineStyle) {
            tree.putClientProperty("JTree.lineStyle", lineStyle);
        }

        //Create the scroll pane and add the tree to it. 
        JScrollPane treeView = new JScrollPane(tree);

        //Create the HTML viewing pane.
        htmlPane = new JEditorPane();
        htmlPane.setEditable(false);
        JScrollPane htmlView = new JScrollPane(htmlPane);

        //Add the scroll panes to a split pane.
        JSplitPane splitPane = new JSplitPane(JSplitPane.VERTICAL_SPLIT);
        splitPane.setTopComponent(treeView);
       // splitPane.setBottomComponent(htmlView);

        Dimension minimumSize = new Dimension(100, 50);
        htmlView.setMinimumSize(minimumSize);
        treeView.setMinimumSize(minimumSize);
        splitPane.setDividerLocation(200); //XXX: ignored in some releases
                                           //of Swing. bug 4101306

        splitPane.setPreferredSize(new Dimension(500, 300));

        //Add the split pane to this panel.
        add(splitPane);
    }

    /**
	 * 
	 */
	private DefaultMutableTreeNode getNewRoot() {
		//Create the nodes.
        return new DefaultMutableTreeNode("Epoch Requirements");
	}

	/** Required by TreeSelectionListener interface. */
    public void valueChanged(TreeSelectionEvent e) {
        DefaultMutableTreeNode node = (DefaultMutableTreeNode)
                           tree.getLastSelectedPathComponent();
        if (node == null) return;
        
        Object nodeInfo = node.getUserObject();

        	if(nodeInfo instanceof Requirement){
        		DefaultMutableTreeNode extend = new DefaultMutableTreeNode("Extends");
        		Requirement r = (Requirement)nodeInfo;
        		Extension ex = r.getOperatesOn();
        		if(ex.isRequirement()){
        			ArrayList reqs = new ArrayList();
        			reqs.add(ex.getRequirement());
        			addRequirementToNode(extend,reqs);
        		}else if(ex.isTask()){
        			DefaultMutableTreeNode taskNode = new DefaultMutableTreeNode(ex.getTask());
        			extend.add(taskNode);
        		}
        	}
    }

  
    
    private void addRequirementToNode(DefaultMutableTreeNode top,List reqs) {
        
    	Iterator iter = reqs.iterator();
    	while(iter.hasNext()){
    		Requirement req = (Requirement)iter.next();
    		DefaultMutableTreeNode reqNode = new DefaultMutableTreeNode(req);
    		top.add(reqNode);
    		
    		addTasksToTree(req, reqNode);
    	}
    	
    }

	private void addTasksToTree(Requirement req, DefaultMutableTreeNode reqNode) {
		Iterator iter2 = req.getTasks().iterator();
		while(iter2.hasNext()){
			DefaultMutableTreeNode taskNode = new DefaultMutableTreeNode(iter2.next());
			reqNode.add(taskNode);
		}
	}
    
    public AbstractAction getAddReqAction(){
    	return new AbstractAction("Create Requirement"){
			public void actionPerformed(ActionEvent e) {
				Requirement r = RequirementsFactory.getGenerator().generateRequirement();		
				List l = new ArrayList();
				l.add(r);
				addRequirementToNode(root,l); 
				tree.setModel(new DefaultTreeModel(root));		
			}    		
    	};
    }
    
    public AbstractAction getClearAction(){
    	return new AbstractAction("Clear Unimplemented Requirements"){
			public void actionPerformed(ActionEvent e) {
				System.out.println("Called: Clear Requirements");
				tree.setModel(new DefaultTreeModel(root = getNewRoot()));
				RequirementRepository.getInstance().clearUnimplementedRequirements();
			}    		
    	};
    }
    /**
     * Create the GUI and show it.  For thread safety,
     * this method should be invoked from the
     * event-dispatching thread.
     */
    private static void createAndShowGUI() {
        if (useSystemLookAndFeel) {
            try {
                UIManager.setLookAndFeel(
                    UIManager.getSystemLookAndFeelClassName());
            } catch (Exception e) {
                System.err.println("Couldn't use system look and feel.");
            }
        }

        //Make sure we have nice window decorations.
        JFrame.setDefaultLookAndFeelDecorated(true);

        //Create and set up the window.
        JFrame frame = new JFrame("Requirements Viewer");
        frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

        //Create and set up the content pane.
        RequirementsTree newContentPane = new RequirementsTree(RequirementsFactory.getGenerator().generateRequirements(1));
        newContentPane.setOpaque(true); //content panes must be opaque
        frame.setContentPane(newContentPane);

        //Display the window.
        frame.pack();
        frame.setVisible(true);
    }

}
