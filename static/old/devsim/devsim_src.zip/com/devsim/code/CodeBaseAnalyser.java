/*
 * Created on 27-Aug-2005
 *
 *
 *
 */
package com.devsim.code;

import java.util.Iterator;

/**
 * @author Ben
 *
 * A utility for analysing the code base
 */
public class CodeBaseAnalyser {
	public static double getAvNumberOfTasksPerFunction(){
		Iterator classes = CodeBase.getAPI().getClasses().iterator();
		double total=0;
		double count=0;
		while (classes.hasNext()){
			Class c = (Class)classes.next();
			Iterator functions =  c.getFunctions().iterator();
			while (functions.hasNext()){
				Function f = (Function)functions.next();
				total+=f.getTasks().size();
				count++;
			}
		}
		double out = (count==0?0:total/count);

		return out;
	}


	public static int getNumberFunctions(){
		Iterator classes = CodeBase.getAPI().getClasses().iterator();
		int total=0;
		while (classes.hasNext()){
			Class c = (Class)classes.next();
			total+=c.getFunctions().size();
		}
		return total;

	}

	public static double getAvFunctionsPerClass(){
		Iterator classes = CodeBase.getAPI().getClasses().iterator();
		double total=0;
		double count=0;
		while (classes.hasNext()){
			Class c = (Class)classes.next();
			total+=c.getFunctions().size();
			count++;
		}
		double out = (count==0?0:total/count);

		return out;
	}

}
