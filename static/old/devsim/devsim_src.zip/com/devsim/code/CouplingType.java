/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.code;

import java.util.List;

/**
 * @author Benjamin Stopford
 *
 * Determine attributes of how classes reference each other (interact)
 *
 */
public class CouplingType {

	public static final CouplingType NO_DATA_TRANSFER = new CouplingType();
	public static final CouplingType UTILISE_DATA_WITHOUT_CHANGE = new CouplingType();
	public static final CouplingType UTILISE_DATA_WITH_CHANGE = new CouplingType();

	Property _retrieveData;
	List _sentData;

}
