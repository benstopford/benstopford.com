/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.code;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;


import com.devsim.plugins.ComplexityInjector;
import com.devsim.requirements.dataobjects.Task;

/**
 * @author Benjamin Stopford
 *
 * Code construct is the super type for all constructs in the code base
 *
 */
public abstract class CodeConstruct {
	private static int max;
	private int id;
	private Task _creationalTask;
	Set _tasks = new HashSet();
	public CodeConstruct(Task creationalTask) {
		_creationalTask = creationalTask;
		_tasks.add(creationalTask);
		max++;
		id = max;
	}

	/**
	 * This should be called by subclasses after construction
	 * if complexity injection is required.
	 */
	protected void constructionComplete(Function callingFunction){
		ComplexityInjector.getInstance().process(this,_creationalTask,callingFunction);
	}

	public int getId(){
		return id;
	}
	public String toString(){
		return getPrefix()+id;
	}
	public String toStringFull(){
		return getPrefix()+id+" "+getTaskString();
	}
	public String getTaskString(){
		String out = "Tasks:";
		Iterator tasks = _tasks.iterator();
		while(tasks.hasNext()){
			out+=((Task)tasks.next()).toString()+";";
		}
		return out;
	}

	public abstract String getPrefix();

	public void addTask(Task task){
		_tasks.add(task);
	}
	public Set getTasks(){
		return _tasks;
	}

}
