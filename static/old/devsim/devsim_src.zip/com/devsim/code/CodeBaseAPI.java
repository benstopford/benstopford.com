/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.code;

import java.util.Set;

import com.devsim.code.CostingProxy.Output;
import com.devsim.evolution.Agent;
import com.devsim.evolution.Cost;
import com.devsim.requirements.dataobjects.Task;

/**
 * @author Benjamin Stopford
 * The API that is used to interact with the code base
 */
public interface CodeBaseAPI {

	/**
	 * Referencing a property does three things:<p>
	 * (1) adds a ref from the caller to the property <p>
	 * (2) adds a ref from the property to the provider <p>
	 * (3) adds a ref directly from the caller to the provider<p>
	 */
	public void referenceProperty(Property p, Function functionToCall, Function funcitonCallingFrom);

	/**
	 * Add a function to the specified task
	 * @param f
	 * @param task
	 */
	public void addFuntionToTask(Function f, Task task);

	/**
	 * Create a new class
	 * @param task
	 * @param callingFunction
	 * @return
	 */
	public Class createClass(Task task, Function callingFunction);
	
	/**
	 * Create a new event
	 * @param task
	 * @return
	 */
	public Event createEvent(Task task);

	
	/**
	 * Create a reference between the two code constucts. 
	 * @param caller
	 * @param provider
	 * @return
	 */
	public Reference createReference(CodeConstruct caller, CodeConstruct provider);

	/**
	 * Creates a new Property and adds it to the code base.
	 */
	public Property createProperty(Class variableType, Class inClass,Task task);

	/**
	 * Create a new function (which is returned)
	 * @param task
	 * @param c
	 * @param callingFunction
	 * @return
	 */
	public Function createFunction(Task task, Class c, Function callingFunction);

	/**
	 * Get all code contstructs that are referenced by the supplied code construct
	 * @param caller
	 * @return
	 */
	public Set getReferencesProvidersForCaller(CodeConstruct caller);
	/**
	 * Get all code contstructs that are call the supplied code construct
	 * @param provider
	 * @return
	 */
	public Set getReferencesCallersForProvider(CodeConstruct provider);
	
	/**
	 * Get all system events
	 * @return
	 */
	public Set getSystemEvents();
	
	/**
	 * Get all functions that were created as a result of a single task
	 * @param task
	 * @return
	 */
	public Set getFunctionsForTask(Task task);
	
	/**
	 * Get all classes that were created as a result of the supplied task
	 * @param task
	 * @return
	 */
	public Set getClassesForTask(Task task);
	
	/**
	 * Get all classes in the code base
	 * @return
	 */
	public Set getClasses();
	
	/**
	 * Get all properties in the code base
	 * @param c
	 * @return
	 */
	public Set getProperties(Class c);
	
	/**
	 * Get all global properties in the code base
	 * @return
	 */
	public Set getPropertiesGlobal();
	
	/**
	 * Get a function selected at random from all functions in the code base
	 * @return
	 */
	public Function getFunctionAtRandom();
	
	/**
	 * Get a class selected at random from all functions in the code base
	 * @return
	 */
	public Class getClassAtRandom();
	
	/**
	 * Get the first class from the list of classes that were created for the supplied task
	 * @param t
	 * @return
	 */
	public Class getFirstClassForTask(Task t);
	
	/**
	 * Get the first function from the list of classes that were created for the supplied class
	 * @param c
	 * @return
	 */
	public Function getFirstFunctionForClass(Class c);

	/**
	 * Sets cost to zero to reset cost counting
	 */
	public void startCosting(Agent agent);

	/**
	 * Gets the implementation cost since the last
	 * startCosting()
	 * @return
	 */
	public Cost getCost();

	/**
	 * Returns details of what code constucts have
	 * been added and what references have been introduced
	 * since the last startCosting()
	 * @return
	 */
	public Output getChanged();


}