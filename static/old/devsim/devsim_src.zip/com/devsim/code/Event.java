/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.code;

import com.devsim.requirements.dataobjects.Task;

/**
 * @author Benjamin Stopford
 * Represents an event of the system
 */
public class Event extends Function {
	Event(Task creationalTask,Class container) {
		super(creationalTask,container,null);
	}

	public String getPrefix() {
		return "Ev";
	}

}
