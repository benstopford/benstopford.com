/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.code;

import java.util.HashSet;
import java.util.Set;

import com.devsim.requirements.dataobjects.Task;


/**
 * @author Benjamin Stopford
 * 
 * Represents a class in the ficticous code base
 */
public class Class extends CodeConstruct {
	Set functions = new HashSet();
	Set properties = new HashSet();

	Class(Task creationalTask,Function callingFunction) {
		super(creationalTask);
		constructionComplete(callingFunction);
	}
	public void addFunction(Function function){
		functions.add(function);
	}
	public void addProperty(Property property){
		properties.add(property);

	}
	public Set getFunctions() {
		return functions;
	}
	public Set getProperties() {
		return properties;
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.units.CodeConstruct#getPrefix()
	 */
	public String getPrefix() {
		return "Cls";
	}
}
