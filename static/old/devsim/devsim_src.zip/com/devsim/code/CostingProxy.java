package com.devsim.code;

import java.util.HashSet;
import java.util.Set;


import com.devsim.evolution.Agent;
import com.devsim.evolution.Cost;
import com.devsim.plugins.CodeMetrics;
import com.devsim.plugins.EnvironmentVariable;
import com.devsim.requirements.dataobjects.Task;

/**
 * This class sits between the agent/evolution policy 
 * and the code base and tots up the costing for 
 * the the code evolution.
 * 
 * The Costing proxy implements the API interface so that it 
 * can act as a proxy between plug-ins and the code base. 
 * It calculates the cost of a specified set of calls. 
 * The costs for the creation of each type of code construct 
 * are defined in the Settings class. 
 * 
 * The costing proxy also records memory of the agent. 
 * Currently the agent�s memory is only incremented when code 
 * constructs are created. This could easily be altered though.
 * 
 * @author Benjamin Stopford
 *
 */
public class CostingProxy implements CodeBaseAPI 
{
	interface Output{
		public Set getAddedCodeConstructs();
		public Set getAddedReferences();
		
	}
	private CodeBaseAPI _api;
	private Cost _cost;
	private Set constructs = new HashSet();
	private Set refs = new HashSet();
	private Agent agent;	
	
	
	public CostingProxy(CodeBaseAPI api){
		if(api instanceof CostingProxy){
			throw new RuntimeException("cannot redecoreate the code base with the costing api more than once.");
		}
		
		_api = api;	
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#startCosting(com.devsim.evolution.Agent)
	 */
	public void startCosting(Agent agent) {
		this.agent = agent;
		_cost = new Cost();	
		constructs.clear();
		refs.clear();
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getCost()
	 */
	public Cost getCost() {
		return _cost;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getChanged()
	 */
	public Output getChanged() {
		return new Output(){

			public Set getAddedCodeConstructs() {
				return constructs;
			}

			public Set getAddedReferences() {
				return refs;
			}
			
		};
	}
	
	
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#createClass(com.devsim.requirements.dataobjects.Task, com.devsim.code.Function)
	 */
	public Class createClass(Task task, Function callingFunction) {		
		_cost.add(EnvironmentVariable.CREATE_CLASS);
		Class c=  _api.createClass(task, callingFunction);
		constructs.add(c);
		agent.getMemory().add(c);
		return c;
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#createFunction(com.devsim.requirements.dataobjects.Task, com.devsim.code.Class, com.devsim.code.Function)
	 */
	public Function createFunction(Task task, Class c, Function callingFunction) {
		_cost.add(EnvironmentVariable.CREATE_FUNCTION);
		Function f = _api.createFunction(task, c, callingFunction);		
		constructs.add(f);
		agent.getMemory().add(f);
		//System.out.println("added to memory: "+f);
		return f;
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#addFuntionToTask(com.devsim.code.Function, com.devsim.requirements.dataobjects.Task)
	 */
	public void addFuntionToTask(Function f, Task task) {
		//THIS IS NON CREATIONAL
		_api.addFuntionToTask(f, task);		
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#createProperty(com.devsim.code.Class, com.devsim.code.Class, com.devsim.requirements.dataobjects.Task)
	 */
	public Property createProperty(Class variableType, Class inClass, Task task) {
		Property p = _api.createProperty(variableType, inClass, task);
		constructs.add(p);
		_cost.add(EnvironmentVariable.CREATE_PROPERTY);
		agent.getMemory().add(p);
		return p;
	}


	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#createEvent(com.devsim.requirements.dataobjects.Task)
	 */
	public Event createEvent(Task task) {
		Event e = _api.createEvent(task);
		constructs.add(e);
		_cost.add(EnvironmentVariable.CREATE_EVENT);
		agent.getMemory().add(e);
		return e;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#createReference(com.devsim.code.CodeConstruct, com.devsim.code.CodeConstruct)
	 */
	public Reference createReference(CodeConstruct caller, CodeConstruct provider) {
		Reference r = _api.createReference(caller,provider);
		constructs.add(r);
		_cost.add(EnvironmentVariable.CREATE_REFERENCE);
		
		//assume that calling a function means you need to understand it
		if(provider instanceof Function){
			_cost.add(CodeMetrics.calculate((Function)provider,agent.getMemory()));
		}
		agent.getMemory().add(provider);		
		
		return r;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getClassAtRandom()
	 */
	public Class getClassAtRandom() {
		return _api.getClassAtRandom();
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getClasses()
	 */
	public Set getClasses() {
		return _api.getClasses();
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getClassesForTask(com.devsim.requirements.dataobjects.Task)
	 */
	public Set getClassesForTask(Task task) {
		return _api.getClassesForTask(task);
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getFirstClassForTask(com.devsim.requirements.dataobjects.Task)
	 */
	public Class getFirstClassForTask(Task t) {
		return _api.getFirstClassForTask(t);
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getFirstFunctionForClass(com.devsim.code.Class)
	 */
	public Function getFirstFunctionForClass(Class c) {
		return _api.getFirstFunctionForClass(c);
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getFunctionAtRandom()
	 */
	public Function getFunctionAtRandom() {
		return _api.getFunctionAtRandom();
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getFunctionsForTask(com.devsim.requirements.dataobjects.Task)
	 */
	public Set getFunctionsForTask(Task task) {
		return _api.getFunctionsForTask(task);
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getProperties(com.devsim.code.Class)
	 */
	public Set getProperties(Class c) {
		return _api.getProperties(c);
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getPropertiesGlobal()
	 */
	public Set getPropertiesGlobal() {
		return _api.getPropertiesGlobal();
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getReferencesProvidersForCaller(com.devsim.code.CodeConstruct)
	 */
	public Set getReferencesProvidersForCaller(CodeConstruct caller) {
		return _api.getReferencesProvidersForCaller(caller);
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getReferencesCallersForProvider(com.devsim.code.CodeConstruct)
	 */
	public Set getReferencesCallersForProvider(CodeConstruct provider) {
		return _api.getReferencesCallersForProvider(provider);
	}
	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getSystemEvents()
	 */
	public Set getSystemEvents() {
		return _api.getSystemEvents();
	}


	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#instantiateClassLevelProperty(com.devsim.code.units.Class, com.devsim.code.units.Class, com.devsim.requirements.dataobjects.Task)
	 */
	public Property instantiateClassLevelProperty(Class variableType, Class inClass, Task task) {
		return _api.createProperty(variableType,inClass,task);
	}


	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#referenceProperty(com.devsim.code.units.Property, com.devsim.code.units.Function, com.devsim.code.units.Function, com.devsim.code.CodeBaseAPI)
	 */
	public void referenceProperty(Property p, Function functionToCall, Function funcitonCallingFrom) {
		_api.referenceProperty(p,functionToCall,funcitonCallingFrom);
	}


	/**
	 * Unit Test
	 * @param args
	 */
//	public static void main(String[] args){
//		CostingProxy proxy = (CostingProxy)CodeBase.getAPI();
//		Requirement req = RequirementsFactory.getGenerator().generateRequirement();	
//		Task t = (Task)req.getTasks().iterator().next();
//		Class c = new Class(t);
//		Property p = new Property(t,c);
//		Function f = new Function(t,c);
//		Reference r = new Reference(f,f,null);
//		Event e = new Event(t,c);
//		
//		proxy.startCosting();
//		proxy.addClass(c);
//		proxy.addClass(c);
//		proxy.addClassNew(t);
//		proxy.addEvent(e); 
//		proxy.addFunction(f,t);
//		proxy.addFunctionNew(t,c);
//		proxy.addFuntionToTask(f,t) ;
//		proxy.addProperty(p,c); 	
//		proxy.addPropertyGlobal(p) ;
//		proxy.addReference(r);
//		Cost cost = proxy.stopCosting();
//		
//		if(cost.getTotalCost()==9){
//			System.out.println("SUCCESS");
//		}else{
//			System.out.println("FAILURE: cost was "+cost.getTotalCost());
//		}
//		
//		proxy.addClass(c);
//		proxy.addClassNew(t);
//		proxy.addEvent(e); 
//		proxy.addFunction(f,t);
//		proxy.addFunctionNew(t,c);
//		proxy.addFuntionToTask(f,t) ;
//		proxy.addProperty(p,c); 	
//		proxy.addPropertyGlobal(p) ;
//		proxy.addReference(r);
//		Cost cost2 = proxy.stopCosting();
//		if(cost2.getTotalCost()==17){
//			System.out.println("SUCCESS");
//		}else{
//			System.out.println("FAILURE: cost was "+cost2.getTotalCost());
//			
//		}
//		
//				
//	}
}
