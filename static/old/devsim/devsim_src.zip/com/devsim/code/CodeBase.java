/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.code;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.devsim.code.CostingProxy.Output;
import com.devsim.evolution.Agent;
import com.devsim.evolution.AgentFactory;
import com.devsim.evolution.Cost;
import com.devsim.requirements.RequirementRepository;
import com.devsim.requirements.dataobjects.Task;
import com.devsim.utils.RandomGen;

/**
 *
 * The code base is the class that is responsible for holding all
 * the simulated code constructs and tying them together. In
 * particular all construction of code constructs is performed
 * in the CodeBase class via the create* methods.
 *
 * @author Benjamin Stopford
 * 		   This class contains the ficticious code base
 *         genereated by the simulation.
 */
/**
 * @author Benjamin Stopford
 *
 */
public class CodeBase implements CodeBaseAPI {
	static final Logger LOGGER = Logger.getLogger("com.devsim.code");

	private static CodeBaseAPI _codeBase = new CostingProxy(new CodeBase());
	private final Set _systemEvents = new HashSet();
	private final Set _classes = new HashSet();
	private final Map _classToFunctionMapOfSets = new HashMap(); //class to function map
	private final Map _taskToFunctionsMapOfSets = new HashMap();
	private final Map _propertyToClassMap = new HashMap();//if the class is null then its a global property
	private final Map _classToPropertyMapOfSets = new HashMap();//if the class is null then its a global property
	private final Set _propertiesGlobal = new HashSet();//if the class is null then its a global property
	private final Map _callersToReferenceMapOfSets = new HashMap();
	private final Map _providerToReferenceMapOfSets = new HashMap();
	private final Set _allReferences = new HashSet();
	private static Cost _totalCost = new Cost();

	public static final void resetCodeBase() {
		_codeBase = new CostingProxy(new CodeBase());
		_totalCost = new Cost();//reset the agents
		AgentFactory.reset();
		RequirementRepository.getInstance().markAllUnimplemented();
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getReferencesProvidersForCaller(com.devsim.code.CodeConstruct)
	 */
	public Set getReferencesProvidersForCaller(CodeConstruct caller) {
		Set s = (Set) _callersToReferenceMapOfSets.get(caller);
		if (s == null) {
			s = new HashSet();
		}
		return s;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getReferencesCallersForProvider(com.devsim.code.CodeConstruct)
	 */
	public Set getReferencesCallersForProvider(CodeConstruct provider) {
		Set s = (Set) _providerToReferenceMapOfSets.get(provider);
		if (s == null) {
			s = new HashSet();
		}
		return s;
	}

	public static CodeBaseAPI getAPI() {
		return _codeBase;
	}


	public static Cost getTotalCost() {
		return _totalCost;
	}


	public void addClass(Class c) {
		_classes.add(c);
		LOGGER.log(Level.INFO, "Added Class:" + c.toString());
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#createClass(com.devsim.requirements.dataobjects.Task, com.devsim.code.Function)
	 */
	public Class createClass(Task task, Function callingFunction) {
		if (callingFunction == null) {
			throw new IllegalArgumentException("Calling funciton is null;");
		}
		checkTask(task);
		Class c = new Class(task, callingFunction);
		addClass(c);
		return c;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getSystemEvents()
	 */
	public Set getSystemEvents() {
		return _systemEvents;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getFunctionsForTask(com.devsim.requirements.dataobjects.Task)
	 */
	public Set getFunctionsForTask(Task task) {
		checkTask(task);
		Set out = (Set) _taskToFunctionsMapOfSets.get(task);
		return out == null ? new HashSet() : out;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getClassesForTask(com.devsim.requirements.dataobjects.Task)
	 */
	public Set getClassesForTask(Task task) {
		checkTask(task);
		Set classes = new HashSet();
		Iterator functions = getFunctionsForTask(task).iterator();
		while (functions.hasNext()) {
			Function f = (Function) functions.next();
			checkFunction(f);
			classes.add(f.getClazz());
		}

		return classes;
	}

	public Set getClasses() {
		return _classes;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#addFuntionToTask(com.devsim.code.Function, com.devsim.requirements.dataobjects.Task)
	 */
	public void addFuntionToTask(Function f, Task task) {
		checkTask(task);

		//first add the task to the function
		f.addTask(task);

		//then record teh mapping locally
		Set functions = (Set) _taskToFunctionsMapOfSets.get(task);

		if (functions == null) {
			functions = new HashSet();
			_taskToFunctionsMapOfSets.put(task, functions);
		}
		functions.add(f);
		LOGGER.log(Level.INFO, "Function:" + f.toString() + " added to task:"
				+ task.toString());
	}

	/**
	 * Creates a new Property and adds it to the code base.
	 * @see com.devsim.code.CodeBaseAPI#createProperty(com.devsim.code.Class, com.devsim.code.Class, com.devsim.requirements.dataobjects.Task)
	 */
	public Property createProperty(Class variableType, Class inClass, Task task) {
		//create a property
		Property prop = new Property(task, variableType);
		//add a reference to denote the type of property it is
		createReference(prop, variableType);
		//add the property to to the code base
		if (inClass == null) {
			addPropertyGlobal(prop);
		} else {
			addProperty(prop, inClass);
		}
		return prop;
	}

	/**
	 * Referencing a property does three things:
	 * <p>
	 * (1) adds a ref from the caller to the property
	 * <p>
	 * (2) adds a ref from the property to the provider
	 * <p>
	 * (3) adds a ref directly from the caller to the provider
	 * <p>
	 * @see com.devsim.code.CodeBaseAPI#referenceProperty(com.devsim.code.Property, com.devsim.code.Function, com.devsim.code.Function)
	 */
	public void referenceProperty(Property p, Function functionToCall,
			Function funcitonCallingFrom) {
		//add a ref from caller to prop
		Reference r1 = new Reference(funcitonCallingFrom, p);
		addReference(r1);
		//add reference from property to provider
		Reference r2 = new Reference(p, functionToCall);
		addReference(r2);
		//add a direct ref from the caller to the provider
		Reference r3 = new Reference(funcitonCallingFrom, functionToCall);
		addReference(r3);
	}

	private void addProperty(Property p, Class c) {
		_propertyToClassMap.put(p, c);
		c.addProperty(p);
		addClassToProperty(c, p);
		LOGGER.log(Level.INFO, "Property:" + p.toString() + " added to class:"
				+ c.toString());
	}

	private void addPropertyGlobal(Property p) {
		_propertiesGlobal.add(p);
		LOGGER.log(Level.INFO, "Global Property:" + p.toString() + " added.");

	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getProperties(com.devsim.code.Class)
	 */
	public Set getProperties(Class c) {
		return (Set) _classToPropertyMapOfSets.get(c);
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getPropertiesGlobal()
	 */
	public Set getPropertiesGlobal() {
		return _propertiesGlobal;
	}



	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getFunctionAtRandom()
	 */
	public Function getFunctionAtRandom() {
		//we only return classes that are on event paths

		Class c = getClassAtRandom();
		if (c == null) {
			LOGGER.log(Level.WARNING,
					"Get Random Class return null? Class count is "
							+ _classes.size());
			return null;
		}
		if (c.getFunctions().size() == 0) {
			LOGGER
					.log(Level.WARNING,
							"Get Random Class return an empty class.");
			return null;
		}

		Set functions = c.getFunctions();
		return (Function) RandomGen.getRandom(functions);
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getClassAtRandom()
	 */
	public Class getClassAtRandom() {
		return (Class) RandomGen.getRandom(_classes);
	}


	private void addFunction(Function func, Task task) {
		checkTask(task);
		Class c = func.getClazz();
		c.addFunction(func);
		if (c == null) {
			throw new IllegalArgumentException(
					"Funcions must be inside modules.");
		}
		Set functionsForClass = getFunctionsForClass(c);
		functionsForClass.add(func);
		addFuntionToTask(func, task);
		//		addClassToTaskMapping(c,task);
		LOGGER.log(Level.INFO, "Function:" + func.toString()
				+ " added to task:" + task.toString());

	}

	private boolean oneFunctionCreated = false;

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#createFunction(com.devsim.requirements.dataobjects.Task, com.devsim.code.Class, com.devsim.code.Function)
	 */
	public Function createFunction(Task task, Class c, Function callingFunction) {
		if (callingFunction == null && !(callingFunction instanceof Event)) {
			throw new IllegalArgumentException("Calling funciton is null;");
		}
		if (!oneFunctionCreated) {
			oneFunctionCreated = true;
			System.out.println("First Function has been created.");
		}
		checkTask(task);
		Function f = new Function(task, c, callingFunction);
		c.addFunction(f);
		addFunction(f, task);
		createReference(callingFunction,f);
		LOGGER.log(Level.INFO, "New Function :" + f.toString()
				+ " added to class:" + c.toString() + " for task:"
				+ task.toString());
		return f;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getFirstClassForTask(com.devsim.requirements.dataobjects.Task)
	 */
	public Class getFirstClassForTask(Task t) {
		Set classes = getClassesForTask(t);
		if (classes != null && classes.size() > 0) {
			return (Class) classes.iterator().next();
		} else {
			throw new IllegalArgumentException("The passed task: "
					+ t.toString() + " has no classes associated with it.");
		}
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getFirstFunctionForClass(com.devsim.code.Class)
	 */
	public Function getFirstFunctionForClass(Class c) {
		Set functions = getFunctionsForClass(c);
		if (functions != null && functions.size() > 0) {
			return (Function) functions.iterator().next();
		} else {
			throw new IllegalArgumentException("The passed class: "
					+ c.toString() + " has no functions associated with it.");
		}
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#createReference(com.devsim.code.CodeConstruct, com.devsim.code.CodeConstruct)
	 */
	public Reference createReference(CodeConstruct caller,
			CodeConstruct provider) {
		if (caller == null || provider == null) {
			if (_classes.size() > 0)
				LOGGER
						.log(Level.WARNING,
								"Reference could not be created as either the caller or provider were null.");
			return null;
		}
		Reference ref = new Reference(caller, provider);
		addReference(ref);
		return ref;
	}

	/**
	 * Crates and event with function and class
	 */
	public Event createEvent(Task task) {
		checkTask(task);
		Class c = new Class(task, null);
		//		Function f = new Function(task,c,null);

		Event event = new Event(task, c);
		c.addFunction(event);
		addFunction(event, task);
		_systemEvents.add(event);

		return event;
	}

	public void startCosting(Agent agent) {
		throw new UnsupportedOperationException(
				"This operation is not supported in the code base itself.");
	}

	public Cost getCost() {
		throw new UnsupportedOperationException(
				"This operation is not supported in the code base itself.");

	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeBaseAPI#getChanged()
	 */
	public Output getChanged() {
		throw new UnsupportedOperationException(
				"This operation is not supported in the code base itself.");
	}

	protected Set getFunctionsForClass(Class m) {
		Set functionsForClass = (Set) _classToFunctionMapOfSets.get(m);
		if (functionsForClass == null) {
			//make sure it is in the set of modules
			_classes.add(m);
			//create a map for it here
			functionsForClass = new HashSet();
			_classToFunctionMapOfSets.put(m, functionsForClass);
		}
		return functionsForClass;
	}
	public String toString() {
		String out = new String("CODE BASE \n");
		Iterator globals = getPropertiesGlobal().iterator();
		out += "Global Variables:\n";
		while (globals.hasNext()) {
			Property p = (Property) globals.next();
			out += ("Global:" + p.toString() + "\n");

		}

		Iterator events = getSystemEvents().iterator();
		out += "Events:\n";
		while (events.hasNext()) {
			Event e = (Event) events.next();
			out += (e.toString() + "\n");
		}
		out += "Classes:\n";

		Iterator classes = getClasses().iterator();
		while (classes.hasNext()) {
			//out+="Classes with Functions:\n";
			Class c = (Class) classes.next();
			out += (c.toString() + "\n");

			//add all the class level properties to this class node
			Iterator props = c.getProperties().iterator();
			while (props.hasNext()) {
				Property p = (Property) props.next();
				out += (p.toString() + "\n");
			}

			//add all the functions to this class node
			Iterator functions = c.getFunctions().iterator();
			//Iterator functions = getFunctionsForClass(c).iterator();
			while (functions.hasNext()) {
				Function f = (Function) functions.next();
				out += (f.toString() + "\n");
			}
		}

		Iterator refs = _allReferences.iterator();
		out += "Refs:\n";
		while (refs.hasNext()) {
			Reference r = (Reference) refs.next();
			out += (r.toString() + "\n");

		}

		return out;
	}

	private CodeBase() {
		LOGGER.setLevel(Level.WARNING);
		LOGGER.log(Level.INFO, "Code Base Created");

	}

	private void addReference(Reference r) {
		LOGGER.log(Level.INFO, "Reference:" + r.toString() + " added.");

		//check that it is not already there


		addValueToMapOfSets(r.getCaller(), r, _callersToReferenceMapOfSets);
		addValueToMapOfSets(r.getProvider(), r, _providerToReferenceMapOfSets);
		_allReferences.add(r);
		HashSet x = new HashSet();
		x.add(r);

	}

	private void addValueToMapOfSets(Object key, Object newValue, Map map) {
		//then record teh mapping locally
		Set set = (Set) map.get(key);

		if (set == null) {
			set = new HashSet();
			map.put(key, set);
		}
		set.add(newValue);

	}

	private void checkTask(Task t) {
		if (t == null || t.equals(Task.NULL)) {
			throw new IllegalArgumentException(
					"Null task supplied to the code base. this is not permitted");
		}
	}

	private void checkFunction(Function f) {
		if (f == null || f.getClazz() == null) {
			throw new IllegalArgumentException(
					"Null function or function does not have a parent class. This is not permitted");
		}
	}

	private void addClassToProperty(Class c, Property p) {
		//then record teh mapping locally
		Set props = (Set) _classToPropertyMapOfSets.get(c);

		if (props == null) {
			props = new HashSet();
			_classToPropertyMapOfSets.put(c, props);
		}
		props.add(p);
		LOGGER.log(Level.INFO, "Property:" + p.toString() + " added to Class:"
				+ c.toString());
	}

}
