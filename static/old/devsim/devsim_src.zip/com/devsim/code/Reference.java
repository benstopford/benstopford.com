/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.code;

import java.util.HashSet;

import com.devsim.plugins.EnvironmentVariable;
import com.devsim.requirements.dataobjects.Task;



/**
* A reference describes one Function or Property calling another.
* It also has a Coupling Type, determined by the evolution policy.
* Coupling types determine whether data is retrieved or changed
* in the reference.
* */

public class Reference {

	private CodeConstruct caller;
	private CodeConstruct provider;
	private CouplingType  couplingType;

	Reference(CodeConstruct caller, CodeConstruct provider){
		this.caller = caller;
		this.provider = provider;
		this.couplingType = EnvironmentVariable.getCouplingType(caller,provider);

		checkType(caller);
		checkType(provider);
	}
	private void checkType(CodeConstruct cc){
		if(cc==null){
			throw new IllegalArgumentException("argument is null.");
		}else if(cc instanceof Property || cc instanceof Function || cc instanceof Class){
			//ok
		}else{
			throw new IllegalArgumentException("Reference only supports properties and functions and Classes. The construct passed was a "+cc.getClass().toString());
		}
	}

	public CodeConstruct getCaller() {
		return caller;
	}
	public CouplingType getCouplingType() {
		return couplingType;
	}
	public CodeConstruct getProvider() {
		return provider;
	}

	public String toString(){
		String out = "Caller:"+getCaller().toString()+" Callee:";
		if(getProvider() instanceof Function){
			Function f = (Function)getProvider();
			out+=f.getClazz().toString()+"."+f.toString();
		}else{
			out+=getProvider().toString();
		}

		return out;
	}

	public int hashCode(){
		return getCaller().getId()+getProvider().getId();
	}
	public boolean equals(Object obj) {
			if(obj instanceof Reference){
		Reference other = (Reference)obj;
		if(other.getProvider()==getProvider()&&
				other.getCaller()==getCaller() &&
				other.getCouplingType() == getCouplingType()){
			return true;
		}
	}
	return false;
}
//
//public static void main(String[] args){
//Class c = new Class(Task.NULL,null);
//Function f = new Function(Task.NULL,c,null);
//	Reference ref = new Reference(f,f);
//	Reference ref2 = new Reference(f,f);
//
//	HashSet set = new HashSet();
//	set.add(ref);
//	set.add(ref2);
//
//	set.contains(ref2);
//
//	if(ref.equals(ref2)){
//		System.out.println("true");
//
//	}
//
//	System.out.println("Done");
//
//}


}
