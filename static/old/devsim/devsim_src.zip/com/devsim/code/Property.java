/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.code;

import com.devsim.requirements.dataobjects.Task;


/**
 * @author Benjamin Stopford
 *
 * Properties represent local variables of a specified type and are
 * held in classes.
 */
public class Property extends CodeConstruct {
	private Class _classType;

	Property(Task creationalTask,Class type) {
		super(creationalTask);
		_classType = type;
		constructionComplete(null);
	}
	public String getPrefix() {
		return "Prop";
	}
	public Class getClassType(){
		return _classType;
	}

}
