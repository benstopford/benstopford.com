/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.code;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.devsim.requirements.dataobjects.Task;


/**
 * @author Benjamin Stopford
 * The basic functional unit of the application this
 * represents a function or procedure in the ficticious code base.
 */
public class Function extends CodeConstruct {

	Class _parentClass;

	Function(Task creationalTask,Class parentModule,Function callingFunction) {
		super(creationalTask);
		_parentClass = parentModule;
		constructionComplete(callingFunction);
	}

	public Class getClazz(){
		return _parentClass;
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.units.CodeConstruct#getPrefix()
	 */
	public String getPrefix() {
		return "Fn";
	}

	/* (non-Javadoc)
	 * @see com.devsim.code.CodeConstruct#getNextCodeConstructs()
	 */
	public Set getNextCodeConstructs() {
		Set references = CodeBase.getAPI().getReferencesProvidersForCaller(this);
		Set out = new HashSet();
		Iterator referencesIter = references.iterator();
		while(referencesIter.hasNext()){
			Reference r = (Reference)referencesIter.next();
			out.add(r.getProvider());
		}
		return out;
	}
}
