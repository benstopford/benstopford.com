/*
 * Created on Aug 9, 2005
 *
 *
 *
 */
package com.devsim.requirements.dataobjects;

/**
 * @author Benjamin Stopford
 *
 *Describes the different types of requirement
*/
public class RequirementType {
	public static final RequirementType UNSPECIFIED = new RequirementType("XX","UNSPECIFIED");
	public static final RequirementType ENTITY = new RequirementType("EN","ENTITY");
	public static final RequirementType OPERATION = new RequirementType("OP","OPERATION");
	public static final RequirementType DATA_ENTITY = new RequirementType("DO","DATA_OBJECT");
	public static final RequirementType SYSTEM_EVENT = new RequirementType("EV","SYSTEM_EVENT");
	public static final RequirementType REQUIREMENT = new RequirementType("RQ","REQUIREMENT");


	private String _key;
	private RequirementType(String key,String fullName){
		_key = key;
	}
	public String getPrefix(){
		return _key;
	}

	public boolean isEntity(){
		return this.equals(ENTITY);
	}
	public boolean isOperation(){
		return this.equals(OPERATION);
	}
	public boolean isDataEntity(){
		return this.equals(DATA_ENTITY);
	}
	public boolean isSystemEvent(){
		return this.equals(SYSTEM_EVENT);
	}
	public boolean isUnspecified(){
		return this.equals(UNSPECIFIED);
	}
}
