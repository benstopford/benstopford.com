/*
 * Created on Aug 11, 2005
 *
 *
 *
 */
package com.devsim.requirements.dataobjects;

/**
 * @author Benjamin Stopford
 *
 * Class wrapper for a Task or Requirement when it is being
 * extended
 */
public class Extension {

	public interface ExtendableType{
	}

	private ExtendableType parent = Task.NULL;

	/**
	 * Constructor for a regular task extension that
	 * extends an existing requirement.
	 * @param parentTask
	 */
	public Extension(ExtendableType parent){
		if(parent ==null){
			throw new IllegalArgumentException
			("Null is not a valid argument for this constuctor.");
		}
		this.parent = parent;
	}



	public RequirementType getRequirementType() {
		RequirementType rt;
		if (parent instanceof Requirement){
			rt =  RequirementType.REQUIREMENT;
		}
		else if(parent instanceof Task){
			rt = ((Task)parent).getRequirementType();
		}
		else{
			throw new IllegalArgumentException("The parent vairable is not of the required type.");
		}
		return rt;
	}

	/**
	 * Get the Requirement or Task that is being extended.
	 * @return
	 */
	public ExtendableType getParent() {
		return parent;
	}


	public boolean isRequirement(){
		return parent instanceof Requirement;
	}
	public boolean isTask(){
		return parent instanceof Task;
	}

	public Requirement getRequirement(){
		if (!isRequirement()){
			throw new UnsupportedOperationException("The parent of this extension is not a Requirement.");
		}
		return (Requirement)parent;
	}

	public Task getTask(){
		if (!isTask()){
			throw new UnsupportedOperationException("The parent of this extension is not a Task.");
		}
		return (Task)parent;
	}

	public String toString(){
		String out = new String("OperatesOn:");
		if(isTask()){
			out+=getTask().toString();
			if(getTask()==Task.NULL){
				out="No Extension Specified";
			}

		}
		else if(isRequirement()){
			out+=getRequirement().toString();
		}
		else{
			out="??!?!?! Task not defined ???!?!?!?!";
		}
		return out;
	}

}
