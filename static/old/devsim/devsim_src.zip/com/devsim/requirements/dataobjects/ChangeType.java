/*
 * Created on 06-Aug-2005
 *
 */
package com.devsim.requirements.dataobjects;

/**
 * @author Ben
 * 
 * A change type. This is a simple enumeration of either - New - Change -
 * Augment. It describes the kind of change that this requirement refers to.
 */
public class ChangeType {
	private static final ChangeType NEW = new ChangeType("NEW");

	private static final ChangeType CHANGE = new ChangeType("CHANGE");

	private static final ChangeType AUGMENT = new ChangeType("AUGMENT");

	private String _changeType;

	private ChangeType(String type) {
		_changeType = type;
	}

	public String toString() {
		return _changeType;
	}

	public String getKey() {
		return _changeType;
	}

	public boolean isNew() {
		return this.equals(NEW);
	}

	public boolean isChange() {
		return this.equals(CHANGE);
	}

	public boolean isAugment() {
		return this.equals(AUGMENT);
	}

	// public boolean equals(ChangeType otherObject){
	// return getKey().equals(otherObject.getKey());
	// }
	public static ChangeType getAugemnt() {
		return AUGMENT;
	}

	public static ChangeType getChange() {
		return CHANGE;
	}

	public static ChangeType getNew() {
		return NEW;
	}
}
