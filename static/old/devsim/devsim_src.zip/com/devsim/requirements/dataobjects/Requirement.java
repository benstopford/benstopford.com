/*
 * Created on 06-Aug-2005
 *
 *
 *
 */
package com.devsim.requirements.dataobjects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;


/**
 * @author Ben
 * A requirement in the simulation
 * */
public class Requirement implements Extension.ExtendableType {
	public static final Requirement NULL = new Requirement(){
		public String toString(){return "Null Requirement";}
	};

	private ChangeType _changeType;
	private List _subTasks = new ArrayList();
	private static int counter;
	private int _id;
	private Extension _operatesOn;
	public boolean implemented = false;
	private int augmentationPercentage;

	public Requirement(){
		counter++;
		_id = counter;
	}


	public void addSubTasks(List subTasks) {
		_subTasks.addAll(subTasks);
	}
	public List getTasks(){
		return _subTasks;
	}
	public ChangeType getChangeType() {
		return _changeType;
	}
	public void setChangeType(ChangeType op) {
		_changeType = op;
	}

	public Extension getOperatesOn() {
		return _operatesOn;
	}
	public void setOperatesOn(Extension operatesOn) {
		this._operatesOn = operatesOn;
	}

	public void setAugmentationPercentage(int percent){
		if(!_changeType.isAugment()){
			throw new UnsupportedOperationException("Cannot set augmentation percentage if requirement is not an augmentation.");
		}

		this.augmentationPercentage = percent;
	}

	public int getAugmentationPercentage(){
		return this.augmentationPercentage;
	}



	public String toString(){
		return "REQ:"+_id+","+_changeType.toString()+","+_operatesOn.toString();
	}
	public String getFullString(){
		StringBuffer buffer = new StringBuffer();
		buffer.append("Change Operator = "+_changeType.toString()+"\n");
		buffer.append("Requirement : "+_id+"\n");
		Iterator iter = _subTasks.iterator();
		while(iter.hasNext()){
			Task unit = (Task)iter.next();
			buffer.append("Task:"+unit.toString()+"\n");
		}

		return buffer.toString();
	}

}
