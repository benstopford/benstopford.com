package com.devsim.requirements.dataobjects;

import java.util.Set;

import com.devsim.code.CodeBase;
import com.devsim.utils.ObjectTracker;

/**
 * @author Ben
 * 
 * Task is the fundemental requirement unit
 * 
 */
public class Task implements Extension.ExtendableType {
	static final ObjectTracker objectTracker = new ObjectTracker();

	public static final Task NULL = new Task(RequirementType.UNSPECIFIED, null,
			0, Requirement.NULL) {
		public String toString() {
			return "NULL_TASK";
		}
	};

	private int _size;

	private int _id;

	private static int _idCount = 0;

	private RequirementType _taskType = RequirementType.UNSPECIFIED;

	private Requirement _parentRequirement;

	private ConceptualType _type;

	public static final int getTaskCount() {
		return Task.objectTracker.getObjectCount();
	}

	/**
	 * 
	 */
	public Task(RequirementType taskType, ConceptualType type, int taskSize,
			Requirement parentRequirement) {
		_type = type;
		_taskType = taskType;
		_idCount++;
		_id = _idCount;
		_parentRequirement = parentRequirement;
		objectTracker.add(this);
		_size = taskSize;
	}

	public ConceptualType getType() {
		return _type;
	}

	private String getId() {
		return _taskType.getPrefix() + _id;
	}

	public String toString() {
		return "Task:" + getId();
	}

	public RequirementType getRequirementType() {
		return _taskType;
	}

	public Requirement getParentRequirement() {
		return _parentRequirement;
	}

	/**
	 * Returns the impact level of this task.
	 * 
	 * @return int between 1 and 100
	 */
	public int getSize() {
		return _size;
	}

	public boolean implemented() {
		if (this == Task.NULL) {
			return false;
		}
		Set functions = CodeBase.getAPI().getFunctionsForTask(this);
		if (functions == null || functions.size() == 0) {
			return false;
		} else {
			return true;
		}
	}
}
