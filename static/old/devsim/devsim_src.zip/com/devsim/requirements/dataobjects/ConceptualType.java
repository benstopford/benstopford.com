package com.devsim.requirements.dataobjects;

import com.devsim.utils.ObjectTracker;

/**
 * Relates requirements that share a conceptual ancestory
 * 
 * @author Ben
 */
public class ConceptualType {

	// global list of all types created
	private static final ObjectTracker typeTracker = new ObjectTracker();

	public static final ConceptualType UNSPECIFIED_TYPE = new ConceptualType();

	public static ConceptualType getExistingTypeAtRandom() {
		return (ConceptualType) typeTracker.getRandom();
	}

	public ConceptualType() {
		typeTracker.add(this);
	}

}
