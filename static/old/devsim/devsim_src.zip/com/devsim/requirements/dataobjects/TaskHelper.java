/*
 * Created on Aug 10, 2005
 *
 *
 *
 */
package com.devsim.requirements.dataobjects;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.devsim.requirements.IRequirementsPolicy;
import com.devsim.utils.RandomGen;

/**
 * @author Benjamin Stopford Task utility functions
 */
public class TaskHelper {

	private static List getAllImplementedTasks() {
		Iterator iter = Task.objectTracker.getAll().iterator();
		List allImpemented = new ArrayList();
		while (iter.hasNext()) {
			Task t = (Task) iter.next();
			if (t.implemented()) {
				allImpemented.add(t);
			}
		}
		return allImpemented;
	}

	public static Task getImplementedTaskAtRandom(IRequirementsPolicy policy) {
		RequirementType requiredType = policy.calcTaskRevisitType();
		List allImplemented = getAllImplementedTasks();
		Task task = Task.NULL;
		int i = 0;
		while (i < 100 && allImplemented.size() > 0) { // crap - take 100
														// swings at it to get
														// it right else just
														// return what we have.
			task = (Task) RandomGen.getRandom(allImplemented);
			if (task.getRequirementType() != requiredType) {
				break;
			}
			i++;
		}
		return task;

	}

	public static Task getExistingTaskAtRandom(IRequirementsPolicy policy) {
		// @TODO - Slow implementation here. should be in three lists. will
		// average 3 calls per request instead of one
		RequirementType requiredType = policy.calcTaskRevisitType();

		Task task = null;
		int i = 0;
		while (i < 100) { // crap - take 100 swings at it to get it right else
							// just return what we have.
			task = (Task) Task.objectTracker.getRandom();
			if (task.getRequirementType() != requiredType) {
				break;
			}
			i++;
		}
		return task;
	}

	public static Task getSystemEventTask() {
		return new Task(RequirementType.SYSTEM_EVENT,
				ConceptualType.UNSPECIFIED_TYPE, 0, Requirement.NULL);
	}

}
