/*
 * Created on Aug 11, 2005
 *
 */
package com.devsim.requirements;

import java.util.HashMap;
import java.util.HashSet;
import java.util.Iterator;
import java.util.Map;
import java.util.Set;

import com.devsim.requirements.dataobjects.Extension;
import com.devsim.requirements.dataobjects.Requirement;
import com.devsim.requirements.dataobjects.Task;

/**
 * @author Benjamin Stopford
 * 
 * Holds all requrements in the system
 */
public class RequirementRepository {
	private static final RequirementRepository singleton = new RequirementRepository();

	private Map _taskToRequirementMap = new HashMap();

	private Set _requirements = new HashSet();

	private RequirementRepository() {
	}

	public static final RequirementRepository getInstance() {
		return singleton;
	}

	public int getImplementedRequriementCount() {
		Iterator it = _requirements.iterator();
		int count = 0;
		while (it.hasNext()) {
			Requirement r = (Requirement) it.next();
			if (r.implemented == true) {
				count++;
			}
		}
		return count;
	}

	public int getImplementedTaskCount() {
		Iterator it = _requirements.iterator();
		int count = 0;
		while (it.hasNext()) {
			Requirement r = (Requirement) it.next();
			if (r.implemented == true) {
				count = count + r.getTasks().size();
			}
		}
		return count;
	}

	public void addRequirement(Requirement r) {
		_requirements.add(r);
		Iterator tasks = r.getTasks().iterator();
		while (tasks.hasNext()) {
			_taskToRequirementMap.put(tasks.next(), r);
		}
	}

	public Set getRequirements() {
		return _requirements;
	}

	public void clearUnimplementedRequirements() {
		Set implemented = new HashSet();
		Iterator it = _requirements.iterator();
		while (it.hasNext()) {
			Requirement r = (Requirement) it.next();
			if (r.implemented == true) {
				implemented.add(r);
			}
		}
		_requirements = implemented;
	}

	public void markAllUnimplemented() {
		Iterator it = _requirements.iterator();
		while (it.hasNext()) {
			Requirement r = (Requirement) it.next();
			r.implemented = false;
		}
	}

	public Requirement getRequirement(Task task) {
		return (Requirement) _taskToRequirementMap.get(task);
	}

	public boolean exists(Extension.ExtendableType extension) {
		if (extension instanceof Requirement) {
			return exists((Requirement) extension);
		} else if (extension instanceof Task) {
			return exists((Task) extension);
		} else {
			throw new IllegalArgumentException(
					"the extension must be a task or requirment.");
		}

	}

	public boolean exists(Task task) {
		return _taskToRequirementMap.containsKey(task);
	}

	public boolean exists(Requirement r) {
		return _requirements.contains(r);
	}

}
