/*
 * Created on Aug 9, 2005
 *
 *
 *
 */
package com.devsim.requirements;

import com.devsim.requirements.dataobjects.ChangeType;
import com.devsim.requirements.dataobjects.RequirementType;

/**
 * @author Benjamin Stopford
 * 
 * The requirements policy provides all the required runtime configerations
 */
public interface IRequirementsPolicy {
	// all probability ints should be in range 0-100

	public int getVersion();

	/**
	 * This method is called prior to creating a new Task to determine what type
	 * of task to create.
	 * 
	 * @return
	 */
	public RequirementType calcTaskType();

	/**
	 * % of overlap between types. a value of 10 would mean that one in 10 types
	 * would be reused types, otherwise they would be new ones
	 * 
	 * @return
	 */
	public int getConceptualTypeReusePercentage();

	/**
	 * Tasks are revisited by new requirements (unless they are of type �New�).
	 * This setting allows control over the distribution of change by task type
	 * (i.e. Entity, Operation etc). So for example it could be configured so
	 * that Operations are changed more often that Data Entities.
	 * 
	 * @return
	 */
	public RequirementType calcTaskRevisitType();

	/**
	 * Number of sub tasks in a requirement. Returning 0 here will result in
	 * there being 1 sub task
	 * 
	 * @return unlimited int
	 */
	public int getMeanNumberOfSubtasks(ChangeType type);

	/**
	 * Provide and average size indicator for each task. This can be any
	 * positive value. The larger the value the greater effect it will have on
	 * the resulting code base
	 * 
	 * @return any positive int
	 */
	public int getMeanTaskSize();

	/**
	 * The Change Type is determined by this call which is made for each new
	 * Task in a requirement.
	 * 
	 * @return a ChangeType
	 */
	public ChangeType calcChangeType();

	/**
	 * Determines the degree of change that will occur during an Augmentation.
	 * This is interpreted as the number of existing tasks in the requirement
	 * that will be augmented. For example an augmentation percentage of 20%
	 * would result in changes in one in five of the functions in the class that
	 * is being augmented
	 * 
	 * @return an int between 1 and 100
	 */
	public int getAgementationPercentage();

	/** ******************************************* */

}