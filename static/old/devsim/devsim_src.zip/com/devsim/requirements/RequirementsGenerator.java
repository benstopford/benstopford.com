/*
 * Created on Aug 9, 2005
 *
 *
 *
 */
package com.devsim.requirements;

import java.util.ArrayList;
import java.util.List;
import java.util.logging.Level;
import java.util.logging.Logger;

import com.devsim.plugins.PolicyFactory;
import com.devsim.requirements.dataobjects.ChangeType;
import com.devsim.requirements.dataobjects.ConceptualType;
import com.devsim.requirements.dataobjects.Extension;
import com.devsim.requirements.dataobjects.Requirement;
import com.devsim.requirements.dataobjects.RequirementType;
import com.devsim.requirements.dataobjects.Task;
import com.devsim.requirements.dataobjects.TaskHelper;
import com.devsim.utils.RandomGen;

/**
 * @author Benjamin Stopford
 * 
 * Generates a single or number of new requirements.
 */
public class RequirementsGenerator {

	private static final Logger LOGGER = Logger
			.getLogger("com.devsim.requirements");

	private IRequirementsPolicy policy;

	public RequirementsGenerator() {
		LOGGER.setLevel(Level.FINE);
	}

	/**
	 * Generate a requirement as a set of tasks New tasks are generally larger
	 * than changes or augmentations
	 * 
	 * @return
	 */
	public Requirement generateRequirement() {

		policy = PolicyFactory.getRequirementsPolicy();

		ChangeType type = policy.calcChangeType();
		// first 7 requirements are always new

		Requirement req = new Requirement();

		req.setChangeType(type);
		if (type.isAugment()) {
			req.setAugmentationPercentage(policy.getAgementationPercentage());
		}

		addTasks(req);

		req.setOperatesOn(new Extension(calcExtensionType(type)));

		// add to the repository
		RequirementRepository.getInstance().addRequirement(req);

		return req;
	}

	public List generateRequirements(int numberOrRequirements) {
		List out = new ArrayList();
		while (numberOrRequirements > 0) {
			numberOrRequirements--;
			out.add(generateRequirement());
		}
		return out;
	}

	/**
	 * - New's always create system events. - Augmentations always act on
	 * requirements. - Changes always act on tasks.
	 */
	private Extension.ExtendableType calcExtensionType(ChangeType type) {
		Extension.ExtendableType ex;

		// never reuse a task when there are less than 10 in total
		if (type.isAugment()) {
			ex = TaskHelper.getImplementedTaskAtRandom(policy)
					.getParentRequirement();
		} else {
			ex = TaskHelper.getImplementedTaskAtRandom(policy);
		}

		if (type.isNew() || ex == null || ex == Task.NULL
				|| ex == Requirement.NULL) {
			ex = TaskHelper.getSystemEventTask();
			// LOGGER.log(Level.INFO,"Event task created "+ex);
		}

		return ex;
	}

	/**
	 * Creates a task associated with associated sub tasks
	 * 
	 * @param unit
	 */
	private Requirement addTasks(Requirement req) {

		// multi level requirement is created
		int meanNumberSubTasks = policy.getMeanNumberOfSubtasks(req
				.getChangeType());
		int numberSubTasks = RandomGen.getFromRange(meanNumberSubTasks * 2);
		numberSubTasks++;

		List subTasks = new ArrayList();

		while (numberSubTasks > 0) {
			numberSubTasks--;
			subTasks.add(getNewTask(req));
		}

		req.addSubTasks(subTasks);

		return req;
	}

	/**
	 * Create a brand new task which can either be an Entity of and Operation
	 * 
	 * @return
	 */

	private Task getNewTask(Requirement parentReq) {
		Task task;
		ConceptualType type = ConceptualType.UNSPECIFIED_TYPE;

		// Stochasticaly generate the type
		if (RandomGen.getPercentage() > policy
				.getConceptualTypeReusePercentage()) {
			type = ConceptualType.getExistingTypeAtRandom();
		} else {
			// generate a new one
			type = new ConceptualType();
		}

		int taskSize = RandomGen.getFromRange(policy.getMeanTaskSize() * 2);

		RequirementType taskType = policy.calcTaskType();
		task = new Task(taskType, type, taskSize, parentReq);

		return task;
	}

}

/**
 * @param addedSubTasks
 */
// private List addExtraSubTaskLevel(List addedSubTasks) {
// Iterator iter = addedSubTasks.iterator();
// List out = new ArrayList();
// while (iter.hasNext()){
// Task subTask = (Task)iter.next();
// List added = addSubTasks(subTask);
// out.addAll(added);
// }
// LOGGER.log(Level.INFO,out.size()+" tertiary sub units were added");
// return out;
// }

/**
 * Gets a requirement task either as a new unit or as one that has been created
 * already according to the appropriate settings
 * 
 * @return
 */
// private Task getNewOrReusedTask(){
// Task unit = null;
//
// if(RandomGen.getPercentage()>policy.getTaskRevisitProbability()){
// unit = Task.getExistingTaskAtRandom(policy);
// if(unit!=null)
// LOGGER.log(Level.INFO,"An old unit was reused: "+unit.toString());
// }
// if(unit==null){
// unit = getNewTask();
// LOGGER.log(Level.INFO,"A new unit was created: "+unit.toString());
// }
//
// return unit;
//
// }
/**
 * adds the appropriate number of subunits
 * 
 * @param unit
 * @return List of the subunits added in this commit
 */
// private List addSubTasks(Task task)
// {
// List out = new ArrayList();
// int mean = policy.getMeanNumberOfTasksPerLevel(_type);
// int r=RandomGen.getFromRange(mean*2); //approximation but good enough for
// here
// while(r>0){
// r--;
// Task subTask = getNewTask();//getNewOrReusedTask();
// out.add(subTask);
// task.addSubTask(subTask);
// }
// LOGGER.log(Level.INFO,out.size()+" primary sub units were added");
// return out;
// }
