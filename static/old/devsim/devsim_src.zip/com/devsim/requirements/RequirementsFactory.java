/*
 * Created on 06-Aug-2005
 *
 *
 *
 */
package com.devsim.requirements;

/**
 * @author Ben
 * 
 * Holds the single instance of the Requirements Generator
 * 
 */
public class RequirementsFactory {

	private static final RequirementsGenerator singleton = new RequirementsGenerator();

	public static RequirementsGenerator getGenerator() {
		return singleton;
	}
}
