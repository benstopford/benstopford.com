/*
 * Created on 27-Aug-2005
 *
 *
 *
 */
package com.devsim.plugins;

import com.devsim.code.CodeBase;
import com.devsim.requirements.IRequirementsPolicy;
import com.devsim.requirements.dataobjects.ChangeType;
import com.devsim.requirements.dataobjects.RequirementType;
import com.devsim.utils.RandomGen;

/**
 * @author Ben
 * 
 * Defines the parameters through which requiremetns are generated
 */
public class RequirementsPolicy implements IRequirementsPolicy {
	RequirementsPolicy() {

	}

	public int getVersion() {
		return 6;
	};

	public int getConceptualTypeReusePercentage() {
		return 3;
	}

	public int getMeanTaskSize() {
		return 2;
	}

	public int getMeanNumberOfSubtasks(ChangeType type) {
		int out = 0;
		if (type.isNew()) {
			out = 5;
		} else if (type.isAugment()) {
			out = 3;
		} else if (type.isChange()) {
			out = 2;
		}
		return out;
	}

	/**
	 * The revisist types are split wiht the percentages 10/55/45
	 */
	public RequirementType calcTaskRevisitType() {
		return calcTaskType();
	}

	/**
	 * The change type is calculated completely at random
	 */
	public ChangeType calcChangeType() {

		int r = RandomGen.getPercentage();

		ChangeType co = null;

		if (r < 15)
			co = ChangeType.getAugemnt();
		else if (r > 60)
			co = ChangeType.getNew();
		else
			co = ChangeType.getChange();

		if (CodeBase.getAPI().getFunctionAtRandom() == null) {
			co = ChangeType.getNew();
		}

		return co;
	}

	/**
	 * The task type is calculated completely at random
	 */
	public RequirementType calcTaskType() {
		int r = RandomGen.getPercentage();

		if (r < 10)
			return RequirementType.ENTITY;
		else if (r > 75)
			return RequirementType.DATA_ENTITY;
		else
			return RequirementType.OPERATION;
	}

	public int getAgementationPercentage() {
		return RandomGen.getPercentage();
	}
}
