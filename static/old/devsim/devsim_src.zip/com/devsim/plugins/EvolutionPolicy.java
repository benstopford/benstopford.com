/*
 * Created on Aug 12, 2005
 */
package com.devsim.plugins;

import com.devsim.code.Class;
import com.devsim.code.CodeBase;
import com.devsim.code.CodeBaseAPI;
import com.devsim.code.CodeConstruct;
import com.devsim.code.CouplingType;
import com.devsim.code.Function;
import com.devsim.code.Property;
import com.devsim.evolution.Cost;
import com.devsim.evolution.IEvolutionPolicy;
import com.devsim.evolution.Memory;
import com.devsim.requirements.dataobjects.RequirementType;
import com.devsim.requirements.dataobjects.Task;
import com.devsim.utils.RandomGen;

/**
 * The Evolution Policy is the plug-in that determines
 * how the code base evolves (along with the Complexity Injector).
 * This is the fundamental place where experiments are configured.
 * The evolution policy has access to a variety of attributes of
 * the simulation that can be used to alter the way that the
 * simulation evolves.
 *
 * @author Benjamin Stopford
 */
public class EvolutionPolicy implements IEvolutionPolicy {
	private Memory _agentMemory;

	/**
	 * Constructor with memory from agent instance that is 
	 * using this evolution policy
	 * @param agentMemory
	 */
	EvolutionPolicy(Memory agentMemory){
		_agentMemory = agentMemory;
	}
	
	/* (non-Javadoc)
	 * @see com.devsim.evolution.IEvolutionPolicy#processNewTask(com.devsim.code.Function, com.devsim.requirements.dataobjects.Task)
	 */
	public Cost processNewTask(final Function startingFunction, final  Task task) {
		RequirementType newReqType;
		newReqType = task.getRequirementType();
		if(newReqType.isEntity() || newReqType.isDataEntity()){
			//New enties result in new classes being created
			final Class c = getAPI().createClass(task, startingFunction);

			//Create refeerences to the new class
			RandomGen.performRandomTimes(new RandomGen.Repeater(){
				public void run() {
					getAPI().createReference(startingFunction,(Function)RandomGen.getRandom(c.getFunctions()));
				}
			}
			,c.getFunctions().size());
		}
		else if(newReqType.isOperation()){

			//Create average of three functions in the existing class
			//Each new class with have a property connected to a couple of other functions in the class
			RandomGen.performRandomTimes(new RandomGen.Repeater(){
				public void run() {
					addFunctionToClassWithRefAndProp(startingFunction, task,getAPI());
				}
			}
			,6);
		}
		else{
			throw new RuntimeException("This should never happen!?!?!");
		}

		return CodeMetrics.calculate(startingFunction,_agentMemory);
	}

	/* (non-Javadoc)
	 * @see com.devsim.evolution.IEvolutionPolicy#processAugmentation(com.devsim.code.Function, com.devsim.requirements.dataobjects.Task)
	 */
	public Cost processAugmentation(final Function baseFunction, final Task task){

		final Class baseClass = baseFunction.getClazz();
		RequirementType newReqType;
		newReqType = task.getRequirementType();
		if(newReqType.isEntity() || newReqType.isDataEntity()){
			//Add the new entity class to the to the code base
			final Class entityClass = getAPI().createClass(task, baseFunction);

			//Create average of 1 EXTRA function to the base class
			RandomGen.performRandomTimes(new RandomGen.Repeater(){
				public void run() {
					Function f = getAPI().createFunction(task,baseClass, baseFunction);
					getAPI().createReference(baseFunction,f);
				}
			}
			,2);

			//Randomly add 0-2 references between base and enitty classes
			RandomGen.performRandomTimes(new RandomGen.Repeater(){
				public void run() {
					Function randomBaseClassFunction = (Function)RandomGen.getRandom(baseClass.getFunctions());
					Function randomEntityClassFunction = (Function)RandomGen.getRandom(entityClass.getFunctions());
					if(randomBaseClassFunction!=null&&randomEntityClassFunction!=null)
						getAPI().createReference(randomBaseClassFunction,randomEntityClassFunction);
				}
			}
			,2);
		}
		else if(newReqType.isOperation()){
			//Create average of 1 EXTRA function to the base class
			RandomGen.performRandomTimes(new RandomGen.Repeater(){
				public void run() {
					Function f = getAPI().createFunction(task,baseClass, baseFunction);
					getAPI().createReference(baseFunction,f);
				}
			}
			,2);

			//Create 0-2 extra references from the base class to randomly selected functions
			RandomGen.performRandomTimes(new RandomGen.Repeater(){
				public void run() {
					getAPI().createReference(baseFunction,getAPI().getFunctionAtRandom());
				}
			}
			,2);

		}
		else{
			throw new RuntimeException("This should never happen!?!?!");
		}
		return CodeMetrics.calculate(baseFunction,_agentMemory);
	}

	/* (non-Javadoc)
	 * @see com.devsim.evolution.IEvolutionPolicy#processChange(com.devsim.code.Function, com.devsim.requirements.dataobjects.Task)
	 */
	public Cost processChange(Function funcToExtend, Task newTask) {
		Cost cost = new Cost();
		
		//add the new task to all functions that use the current one
		funcToExtend.addTask(newTask);
		
		//add a new function with properties linkign them back to original fucntion
		addFunctionToClassWithRefAndProp(funcToExtend,newTask,getAPI());
		
		//half the time add a new ref
		if(RandomGen.getBool()){
			getAPI().createReference(funcToExtend,getAPI().getFunctionAtRandom());
		}
		cost.add(CodeMetrics.calculate(funcToExtend,_agentMemory));

		return cost;
	}

	/**
	 * @return Returns the _api.
	 */
	CodeBaseAPI getAPI() {
		return CodeBase.getAPI();
	}

	/**
	 * Adds a new function with a reference and
	 * properteis from the creating function
	 * @param startingFunction
	 * @param task
	 */
	static Function addFunctionToClassWithRefAndProp(Function startingFunction, Task task,CodeBaseAPI api) {
		Class startingClass = startingFunction.getClazz();
		Function f = api.createFunction(task,startingClass, startingFunction);
		api.createReference(startingFunction,f);

		//create a property
		Property p = api.createProperty(api.getClassAtRandom(),startingClass,task);
		api.createReference(f,p);

		//link the new property to the new function and 2 other random functions
		Function f1 = (Function)RandomGen.getRandom(startingClass.getFunctions());
		Function f2 = (Function)RandomGen.getRandom(startingClass.getFunctions());
		api.createReference(f1,p);
		api.createReference(f2,p);

		return f;
	}

	/* (non-Javadoc)
	 * @see com.devsim.evolution.IEvolutionPolicy#getCouplingType(com.devsim.code.CodeConstruct, com.devsim.code.CodeConstruct)
	 */
	public CouplingType getCouplingType(CodeConstruct caller, CodeConstruct provider){
		return EnvironmentVariable.getCouplingType(caller,provider);
	}
		
}
