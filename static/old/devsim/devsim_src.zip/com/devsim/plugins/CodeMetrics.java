package com.devsim.plugins;

import java.util.HashSet;
import java.util.Iterator;
import java.util.Set;

import com.devsim.code.CodeBase;
import com.devsim.code.CodeBaseAPI;
import com.devsim.code.Function;
import com.devsim.evolution.Cost;
import com.devsim.evolution.Memory;
/**
 * Class provides code metrics that should be utalised to measure the code. 
 * Measuremnt is done in terms of Cost which is an arbitary integer value.
 * @author stopforb
 *
 */
public class CodeMetrics {
	public static final Cost calculate(Function f,Memory agentMemory){
		if(f==null||agentMemory==null){
			throw new IllegalArgumentException("Arguments cannot be null.");
		}
		Cost cost = new Cost();
		cost.add(calculateComplexity(f,agentMemory));
		cost.add(calculateTestability(f,agentMemory));
		return cost;
	}

	private static final Cost calculateTestability(Function f,Memory agentMemory){
		return Cost.NO_COST;
	}
	
	/**
	 * Provides a basic complexity metric that does the following 
	 * <p>
	 * > The number of Requirement Tasks that contributed to the function.<p>
	 * > The number of functions that refer to it (i.e. the amount that it is reused).<p>
	 * > The number of other functions that it refers to (i.e. the number of outward references).<p>
	 * 
	 * Comprehension of a function is assumed to requires knowledge of all functions in that class so the above is calculated itteratively. <p>
	 * @param f
	 * @param agentMemory
	 * @return
	 */
	private static final Cost calculateComplexity(Function f,Memory agentMemory){
		Cost cost = new Cost();
		//you need to understand the whole class
		Iterator functions = f.getClazz().getFunctions().iterator();
		while (functions.hasNext()){
			Function f2 = (Function)functions.next();
			cost.add(calculateFunctionComplexity(f2,agentMemory));
		}
		
		//you need to understand functions that you reference (but just to one level)
		Set refs = new HashSet();
		refs.addAll(getAPI().getReferencesProvidersForCaller(f));
		Iterator functions2 = refs.iterator();
		while (functions.hasNext()){
			Object o = functions2.next();
			if(o instanceof Function){				
				Function f2 = (Function)o;
				//refs.addAll(_api.getReferencesCallers(f));
				cost.add(calculateFunctionComplexity(f2,agentMemory));
			}
		}
	
		return cost;		
	}

	/**
	 * Complixity of a single function in isolation
	 * @param f
	 * @return
	 */
	private static Cost calculateFunctionComplexity(Function f,Memory agentMemory) {
		Cost c = new Cost();
		int value=0;
		if(f==null){
			f = null;
		}
		//not cost is inclured if the agent remembers it
		if(agentMemory!=null && agentMemory.remembers(f)){
			c.addRemembered();
			return c;
		}
	
		//add the nuymber of tasks that the method has
		int task = f.getTasks().size()*3;
		//add the number of outward refs
		int out = getAPI().getReferencesProvidersForCaller(f).size();
		
		value = task+out;
		c.addComplexity(value);
		return c;
	}

	/**
	 * @return Returns the _api.
	 */
	private static CodeBaseAPI getAPI() {
		return CodeBase.getAPI();
	}
	
}
	