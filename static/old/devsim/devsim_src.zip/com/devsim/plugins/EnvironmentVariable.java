/*
 * Created on 26-Aug-2005
 *
 *
 *
 */
package com.devsim.plugins;

import com.devsim.code.CodeConstruct;
import com.devsim.code.CouplingType;
import com.devsim.evolution.Cost;

/**
 * @author Ben
 *Global applicatoin settings
 */
public class EnvironmentVariable {

	/**
	 * this determines the number of epochs after which the
	 * agents memory of what they have implemented will
	 * fade completely
	 */
	public static final int MAX_EPOCHS_BEFORE_MEMORY_LOSS = 100;
	public static  int NUMBER_OF_AGENTS = 1000;
	public static String PATH_TO_LOG = "C:\\Control1.txt";
	public static final Cost CREATE_CLASS = new Cost(15);
	public static final Cost CREATE_FUNCTION = new Cost(10);
	public static final Cost CREATE_PROPERTY = new Cost(2);
	public static final Cost CREATE_REFERENCE = new Cost(2);
	public static final Cost CREATE_EVENT = new Cost(15);
	
	
	/**
	 * Determine the coupling type that should be used
	 * when refering from one class to anohter
	 * @return
	 */
	public static CouplingType getCouplingType(CodeConstruct caller, CodeConstruct provider){
		// to be implemented properly
		return CouplingType.NO_DATA_TRANSFER;
	}
}
