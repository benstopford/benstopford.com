/*
 * Created on 06-Aug-2005
 *
 *
 *
 */
package com.devsim.plugins;

import com.devsim.evolution.IEvolutionPolicy;
import com.devsim.evolution.Memory;
import com.devsim.requirements.IRequirementsPolicy;



/**
 * @author Ben
 * Controls policy instances
 */
public class PolicyFactory  {
	private static final IRequirementsPolicy reqPolicy = new RequirementsPolicy();

	public static IRequirementsPolicy getRequirementsPolicy(){
		return reqPolicy;//(RequirementsPolicy)requirementPolicyMap.get(type);
	}

	public static IEvolutionPolicy getEvolutionPolicy(Memory m){
		return new EvolutionPolicy(m);
	}
}
