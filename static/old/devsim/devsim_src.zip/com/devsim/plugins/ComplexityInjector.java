package com.devsim.plugins;

import java.util.ArrayList;
import java.util.Iterator;
import java.util.List;

import com.devsim.code.Class;
import com.devsim.code.CodeBase;
import com.devsim.code.CodeBaseAPI;
import com.devsim.code.CodeConstruct;
import com.devsim.code.Event;
import com.devsim.code.Function;
import com.devsim.code.Property;
import com.devsim.requirements.dataobjects.Task;
import com.devsim.utils.RandomGen;

/**
 * The complexity injector is responsible for injecting extra code
 * constructs into teh code base. This normally called from the 
 * COsting proxy when constucts are created. 
 * @author stopforb
 *
 */
public class ComplexityInjector {

	private static final ComplexityInjector instance = new ComplexityInjector();
	
	private ComplexityInjector(){}

	/**
	 * Returns the injector singleton
	 * @return
	 */
	public static final ComplexityInjector getInstance() {
		return instance;
	}
	
	/**
	 * Injects the specified level of complexity into the code construct 
	 * @param cc
	 * @param task
	 * @param callingFunction
	 */
	public void process (CodeConstruct cc,Task task,final Function callingFunction){
		if(cc instanceof Function){
			processFunction((Function) cc,task);
		}
		else if(cc instanceof Class){
			processClass((Class) cc, task,callingFunction);
		}
		else if(cc instanceof Event){
			processEvent((Event) cc, task);
		}
		else if(cc instanceof Property){
			processProperty((Property) cc, task);
		}
	}
	
	/**
	 * Create a random number of functinos in each new class. Note that this will only
	 * work if the calling fucntion has been passed (for example in system events). If 
	 * this is not passed nothing will be injected.
	 */
	private void processClass(final Class c, final Task task,final Function callingFunction){
		final List functions = new ArrayList();
		final List properties= new ArrayList();
		
		if(callingFunction==null){
			return;
		}
		
		//create average of three functions (note that these will have compleity
		//added in the processFunciton call below)
		RandomGen.performRandomTimesAtLeastOnce(new RandomGen.Repeater(){
			public void run() {
				functions.add(getAPI().createFunction(task,c, callingFunction));
			}				
		}					
		,6);
		
		//create average of three properties of random types
		RandomGen.performRandomTimesAtLeastOnce(new RandomGen.Repeater(){
			public void run() {
				Property p = getAPI().createProperty(getAPI().getClassAtRandom(),c,task);
				properties.add(p);
				getAPI().createReference((Function)RandomGen.getRandom(functions),p);
			}				
		}					
		,6);
		
		//for each function randomly link to a propterty (functions will be added in processFunction method below)
		Iterator function = functions.iterator();
		while(function.hasNext()){
			final Function f = (Function)function.next();
			if(RandomGen.getBool()==true){
				//link to a random number of properties created above
				RandomGen.performRandomTimes(new RandomGen.Repeater(){
					public void run() {
						Property p = (Property)RandomGen.getRandom(properties);
						getAPI().createReference(f,p);
					}				
				}					
				,properties.size());				
			}
		}
	}
	private void processProperty(Property p, Task task){
		//Properties currently have not complexity added
	}
	private void processEvent(Event e, Task task){
		//events currently have not complexity added
	}
	
	/**
	 * Make a random number of references from the function
	 * @param f
	 * @param task
	 */
	private void processFunction(final Function f, Task task){
		//add on average three references outwards at random
	
		if(RandomGen.getBool()==true){
			//link to around 2 random functions
			RandomGen.performRandomTimes(new RandomGen.Repeater(){
				public void run() {
					getAPI().createReference(f,getAPI().getFunctionAtRandom());
				}				
			}					
			,4);
		}
	}

	

	/**
	 * @return Returns the _api.
	 */
	private CodeBaseAPI getAPI() {
		return CodeBase.getAPI();
	}

}
