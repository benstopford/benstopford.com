package com.devsim.utils;

import java.util.Collection;
import java.util.Random;

/**
 * @author Ben
 * 
 * This class provides a stochastic baisis to experiments through a set of
 * different randdom number based utilities
 */
public class RandomGen {
	private static final Random rand = new Random(System.currentTimeMillis());

	/**
	 * Generate a random integer between 1 and 100
	 * 
	 * @return
	 */
	public static int getPercentage() {
		Random rand = getRandom();
		float f = rand.nextFloat();
		f = f * 100;
		return (int) f;
	}

	private static Random getRandom() {
		return rand;
	}

	public static boolean getBool() {
		Random rand = getRandom();
		float f = rand.nextFloat();
		f = f * 100;
		return (f > 50) ? false : true;
	}

	/**
	 * Returns a random number between 0 and max-1 range supplied as arg
	 */
	public static int getFromRange(int max) {
		Random rand = getRandom();
		float f = rand.nextFloat();
		f = f * max;
		return (int) f;
	}

	/**
	 * Perform the repeater a random number of times up to the max
	 * @param thingToDo
	 * @param maxNumber
	 */
	public static void performRandomTimes(Repeater thingToDo, int maxNumber) {
		int i = RandomGen.getFromRange(maxNumber);
		while (i > 0) {
			i--;
			thingToDo.run();
		}
	}
	
	/**
	 * Perform the repeater a random number of times up to the max, but at least once
	 * @param thingToDo
	 * @param maxNumber
	 */
	public static void performRandomTimesAtLeastOnce(Repeater thingToDo,
			int maxNumber) {
		int i = RandomGen.getFromRange(maxNumber);
		if (i == 0)
			i++;
		while (i > 0) {
			i--;
			thingToDo.run();
		}
	}

	/**
	 * Select a value at random from the passed in collection
	 * 
	 * @param set
	 * @return
	 */
	public static Object getRandom(Collection set) {
		Object[] vals = set.toArray();
		Integer randomIndex = new Integer(getFromRange(vals.length));
		if (vals.length == 0)
			return null;
		return vals[randomIndex.intValue()];
	}

	public interface Repeater {
		public void run();
	}

}
