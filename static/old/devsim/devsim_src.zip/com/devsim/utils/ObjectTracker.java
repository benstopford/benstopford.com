package com.devsim.utils;

import java.util.ArrayList;
import java.util.List;

/**
 * @author Ben
 * 
 * Object Tracker is used to track numers of object instances
 */
public class ObjectTracker {
	private final List _allObjects = new ArrayList();

	public Object getRandom() {
		if (isEmpty()) {
			throw new RuntimeException(
					"The getRandom object call failed as there are not objects in the list to select.");
		}

		return RandomGen.getRandom(_allObjects);
	}

	public void add(Object o) {
		_allObjects.add(o);
	}

	public boolean isEmpty() {
		return _allObjects.size() == 0;
	}

	public int getObjectCount() {
		return _allObjects.size();
	}

	public void clearTypesList() {
		_allObjects.clear();
	}

	public void clear() {
		_allObjects.clear();
	}

	public List getAll() {
		return _allObjects;
	}

}
