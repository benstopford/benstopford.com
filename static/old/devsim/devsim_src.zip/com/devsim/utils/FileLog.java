package com.devsim.utils;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;


import com.devsim.code.CodeBase;
import com.devsim.code.CodeBaseAnalyser;
import com.devsim.evolution.Cost;
import com.devsim.plugins.EnvironmentVariable;
import com.devsim.requirements.RequirementRepository;
import com.devsim.requirements.dataobjects.Requirement;
/**
 * 
 * @author Ben
 *
 *
 * Class used to write results to an output file
 */
public class FileLog {
private static String log = addHeader();
	public static void clear(){
		log = addHeader();
	}
	
	public static final String getLog(){
		return log;
	}
	
	public static final void addLine(String text){
		log+=text+"\n";
	}
	
	public static void save(){
	    try {
	    	File file = new File(EnvironmentVariable.PATH_TO_LOG);
	    	BufferedWriter out = new BufferedWriter(new FileWriter(file));
	        out.write(log);
	        
	        out.close();
	    } catch (IOException e) {
	    	e.printStackTrace();
	    }
	}

	public  static void logRequirementCost(Cost total,Requirement r) {
		if(total.getTotalCost()>0){
			FileLog.addLine(
					RequirementRepository.getInstance().getImplementedRequriementCount() +"	"+
					RequirementRepository.getInstance().getImplementedTaskCount() +"	"+
					CodeBase.getAPI().getClasses().size() +"	"+
					CodeBaseAnalyser.getNumberFunctions() +"	"+
					trim(CodeBaseAnalyser.getAvNumberOfTasksPerFunction()+"",10)+"	"+ 
					trim(CodeBaseAnalyser.getAvFunctionsPerClass()+"",10)+"	"+
					total.getImplementationCost() +"	"+				
					total.getComplexityCost()+ "	" +
					EnvironmentVariable.NUMBER_OF_AGENTS+ "	" +
					total.getNumberOfRecals()+ "	" +
					r.getChangeType().toString()+ "	" 
					);
		}
	}

	private static String trim(String s, int length){
		if (s.length()<=length){
			return s;
		}else{
			return s.substring(0,length);
		}
	}
	private static String addHeader() {
		return new String (
				"Epoch Count" +"	"+
				"Task Count" +"	"+
				"Class Count" +"	"+
				"Function Count" +"	"+
				"Task/Fn"+"	"+ 
				"Fn/Class"  +"	"+
				"Impl Cost" +"	"+				
				"Metric Cost"+ "	" +
				"# Developers"+ "	" +
				"Recalls"+ "	" +
				"Change Type"+ "	\n"  
				);
	}
}
