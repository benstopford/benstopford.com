package com.rbs.odc.interview;

public class TractorInDitchException extends RuntimeException {

}
